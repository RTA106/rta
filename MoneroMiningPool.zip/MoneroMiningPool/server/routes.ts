import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertMiningStatsSchema, 
  insertPayoutSchema 
} from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Error handling middleware
  const handleError = (err: any, res: Response) => {
    console.error("API Error:", err);
    if (err instanceof ZodError) {
      return res.status(400).json({ 
        message: "Validation error", 
        errors: err.errors 
      });
    }
    return res.status(500).json({ message: err.message || "Internal server error" });
  };

  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (err) {
      handleError(err, res);
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (err) {
      handleError(err, res);
    }
  });

  // Mining routes
  app.post("/api/mining/start", async (req, res) => {
    try {
      const { userId, hashrate } = req.body;
      
      if (!userId || typeof hashrate !== 'number') {
        return res.status(400).json({ message: "Invalid request. userId and hashrate are required" });
      }
      
      const user = await storage.getUser(parseInt(userId));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Update user's hash power
      const updatedUser = await storage.updateUserHashPower(user.id, hashrate);
      
      // Update pool stats
      const latestPoolStats = await storage.getLatestPoolStats();
      if (latestPoolStats) {
        const newTotalHashrate = (Number(latestPoolStats.totalHashrate) + hashrate).toString();
        const newActiveMiners = latestPoolStats.activeMiners + 1;
        
        await storage.updatePoolStats(latestPoolStats.id, {
          totalHashrate: newTotalHashrate,
          activeMiners: newActiveMiners
        });
      }
      
      // Create mining stats entry
      const miningStats = await storage.createMiningStats({
        userId: user.id,
        hashrate: hashrate.toString(),
        sharesAccepted: 0,
        sharesRejected: 0
      });
      
      res.json({
        message: "Mining started successfully",
        user: updatedUser,
        miningStats
      });
    } catch (err) {
      handleError(err, res);
    }
  });

  app.post("/api/mining/stop", async (req, res) => {
    try {
      const { userId } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const user = await storage.getUser(parseInt(userId));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const currentHashrate = Number(user.hashPower);
      
      // Update pool stats
      const latestPoolStats = await storage.getLatestPoolStats();
      if (latestPoolStats) {
        const newTotalHashrate = Math.max(0, Number(latestPoolStats.totalHashrate) - currentHashrate).toString();
        const newActiveMiners = Math.max(0, latestPoolStats.activeMiners - 1);
        
        await storage.updatePoolStats(latestPoolStats.id, {
          totalHashrate: newTotalHashrate,
          activeMiners: newActiveMiners
        });
      }
      
      // Update user's hash power to 0
      const updatedUser = await storage.updateUserHashPower(user.id, 0);
      
      res.json({
        message: "Mining stopped successfully",
        user: updatedUser
      });
    } catch (err) {
      handleError(err, res);
    }
  });

  app.post("/api/mining/update", async (req, res) => {
    try {
      const { userId, hashrate, sharesAccepted, sharesRejected } = req.body;
      
      if (!userId || typeof hashrate !== 'number') {
        return res.status(400).json({ 
          message: "Invalid request. userId and hashrate are required" 
        });
      }
      
      const user = await storage.getUser(parseInt(userId));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Update pool stats with hashrate difference
      const latestPoolStats = await storage.getLatestPoolStats();
      if (latestPoolStats) {
        const hashrateDiff = hashrate - Number(user.hashPower);
        const newTotalHashrate = (Number(latestPoolStats.totalHashrate) + hashrateDiff).toString();
        
        await storage.updatePoolStats(latestPoolStats.id, {
          totalHashrate: newTotalHashrate
        });
      }
      
      // Update user's hash power
      const updatedUser = await storage.updateUserHashPower(user.id, hashrate);
      
      // Create new mining stats entry
      const miningStats = await storage.createMiningStats({
        userId: user.id,
        hashrate: hashrate.toString(),
        sharesAccepted: sharesAccepted || 0,
        sharesRejected: sharesRejected || 0
      });
      
      res.json({
        message: "Mining stats updated successfully",
        user: updatedUser,
        miningStats
      });
    } catch (err) {
      handleError(err, res);
    }
  });

  // Stats routes
  app.get("/api/stats/pool", async (req, res) => {
    try {
      const poolStats = await storage.getLatestPoolStats();
      if (!poolStats) {
        return res.status(404).json({ message: "Pool stats not found" });
      }
      
      res.json(poolStats);
    } catch (err) {
      handleError(err, res);
    }
  });

  app.get("/api/stats/miners/top", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 5;
      const topMiners = await storage.getTopMiners(limit);
      
      res.json(topMiners);
    } catch (err) {
      handleError(err, res);
    }
  });

  app.get("/api/stats/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const miningStats = await storage.getMiningStatsByUserId(userId);
      const payouts = await storage.getPayoutsByUserId(userId);
      
      res.json({
        user,
        miningStats,
        payouts
      });
    } catch (err) {
      handleError(err, res);
    }
  });

  // Payouts routes
  app.get("/api/payouts/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const payouts = await storage.getPayoutsByUserId(userId);
      
      res.json(payouts);
    } catch (err) {
      handleError(err, res);
    }
  });

  app.post("/api/payouts", async (req, res) => {
    try {
      const payoutData = insertPayoutSchema.parse(req.body);
      const payout = await storage.createPayout(payoutData);
      
      res.status(201).json(payout);
    } catch (err) {
      handleError(err, res);
    }
  });

  // For demonstration - create a demo user if none exists
  const createDemoUser = async () => {
    const existingUser = await storage.getUserByUsername("demo_user");
    if (!existingUser) {
      await storage.createUser({
        username: "demo_user",
        password: "password123",
        walletAddress: "4BrL51JCc9NGQ71kWhnYoDRffsDZy7m1HUU7MRU4nUMXAHNFBEJhkTZV9HdaL4gfuNBxLPc3BeMkLGaPbF5vWtANQs4pDSFQgLM"
      });
    }
  };
  
  createDemoUser().catch(console.error);

  return httpServer;
}
