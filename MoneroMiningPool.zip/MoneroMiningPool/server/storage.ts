import {
  users, type User, type InsertUser,
  miningStats, type MiningStats, type InsertMiningStats,
  payouts, type Payout, type InsertPayout,
  poolStats, type PoolStats, type InsertPoolStats
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserHashPower(id: number, hashPower: number): Promise<User | undefined>;

  // Mining stats methods
  getMiningStatsByUserId(userId: number): Promise<MiningStats[]>;
  createMiningStats(stats: InsertMiningStats): Promise<MiningStats>;

  // Payout methods
  getPayoutsByUserId(userId: number): Promise<Payout[]>;
  createPayout(payout: InsertPayout): Promise<Payout>;
  updatePayoutStatus(id: number, status: string, transactionId?: string): Promise<Payout | undefined>;

  // Pool stats methods
  getLatestPoolStats(): Promise<PoolStats | undefined>;
  createPoolStats(stats: InsertPoolStats): Promise<PoolStats>;
  updatePoolStats(id: number, stats: Partial<InsertPoolStats>): Promise<PoolStats | undefined>;
  
  // Top miners
  getTopMiners(limit: number): Promise<User[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private miningStats: Map<number, MiningStats>;
  private payouts: Map<number, Payout>;
  private poolStats: Map<number, PoolStats>;
  
  private currentUserId: number;
  private currentMiningStatsId: number;
  private currentPayoutId: number;
  private currentPoolStatsId: number;

  constructor() {
    this.users = new Map();
    this.miningStats = new Map();
    this.payouts = new Map();
    this.poolStats = new Map();
    
    this.currentUserId = 1;
    this.currentMiningStatsId = 1;
    this.currentPayoutId = 1;
    this.currentPoolStatsId = 1;
    
    // Initialize with default pool stats
    this.createPoolStats({
      totalHashrate: "156780",
      activeMiners: 423,
      blocksFound: 5,
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const timestamp = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      hashPower: "0", 
      totalHashContribution: "0", 
      totalRewards: "0",
      joinedAt: timestamp 
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserHashPower(id: number, hashPower: number): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      hashPower: hashPower.toString(),
      totalHashContribution: (Number(user.totalHashContribution) + hashPower).toString()
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Mining stats methods
  async getMiningStatsByUserId(userId: number): Promise<MiningStats[]> {
    return Array.from(this.miningStats.values()).filter(
      (stats) => stats.userId === userId,
    );
  }

  async createMiningStats(insertStats: InsertMiningStats): Promise<MiningStats> {
    const id = this.currentMiningStatsId++;
    const timestamp = new Date();
    const stats: MiningStats = { ...insertStats, id, timestamp };
    this.miningStats.set(id, stats);
    return stats;
  }

  // Payout methods
  async getPayoutsByUserId(userId: number): Promise<Payout[]> {
    return Array.from(this.payouts.values())
      .filter((payout) => payout.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async createPayout(insertPayout: InsertPayout): Promise<Payout> {
    const id = this.currentPayoutId++;
    const timestamp = new Date();
    const payout: Payout = { ...insertPayout, id, timestamp };
    this.payouts.set(id, payout);
    return payout;
  }

  async updatePayoutStatus(id: number, status: string, transactionId?: string): Promise<Payout | undefined> {
    const payout = this.payouts.get(id);
    if (!payout) return undefined;
    
    const updatedPayout = { 
      ...payout, 
      status,
      ...(transactionId && { transactionId })
    };
    this.payouts.set(id, updatedPayout);
    return updatedPayout;
  }

  // Pool stats methods
  async getLatestPoolStats(): Promise<PoolStats | undefined> {
    const allStats = Array.from(this.poolStats.values());
    if (allStats.length === 0) return undefined;
    
    return allStats.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())[0];
  }

  async createPoolStats(insertStats: InsertPoolStats): Promise<PoolStats> {
    const id = this.currentPoolStatsId++;
    const timestamp = new Date();
    const stats: PoolStats = { ...insertStats, id, timestamp };
    this.poolStats.set(id, stats);
    return stats;
  }

  async updatePoolStats(id: number, partialStats: Partial<InsertPoolStats>): Promise<PoolStats | undefined> {
    const stats = this.poolStats.get(id);
    if (!stats) return undefined;
    
    const updatedStats = { ...stats, ...partialStats };
    this.poolStats.set(id, updatedStats);
    return updatedStats;
  }
  
  // Top miners
  async getTopMiners(limit: number): Promise<User[]> {
    return Array.from(this.users.values())
      .sort((a, b) => Number(b.hashPower) - Number(a.hashPower))
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
