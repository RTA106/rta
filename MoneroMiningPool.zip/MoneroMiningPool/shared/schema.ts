import { pgTable, text, serial, integer, boolean, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  walletAddress: text("wallet_address"),
  hashPower: numeric("hash_power").default("0"),
  totalHashContribution: numeric("total_hash_contribution").default("0"),
  totalRewards: numeric("total_rewards").default("0"),
  joinedAt: timestamp("joined_at").defaultNow(),
});

export const miningStats = pgTable("mining_stats", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  hashrate: numeric("hashrate").default("0"),
  sharesAccepted: integer("shares_accepted").default(0),
  sharesRejected: integer("shares_rejected").default(0),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const payouts = pgTable("payouts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  amount: numeric("amount").notNull(),
  status: text("status").notNull().default("pending"),
  transactionId: text("transaction_id"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const poolStats = pgTable("pool_stats", {
  id: serial("id").primaryKey(),
  totalHashrate: numeric("total_hashrate").default("0"),
  activeMiners: integer("active_miners").default(0),
  blocksFound: integer("blocks_found").default(0),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  walletAddress: true,
});

export const insertMiningStatsSchema = createInsertSchema(miningStats).pick({
  userId: true,
  hashrate: true,
  sharesAccepted: true,
  sharesRejected: true,
});

export const insertPayoutSchema = createInsertSchema(payouts).pick({
  userId: true,
  amount: true,
  status: true,
  transactionId: true,
});

export const insertPoolStatsSchema = createInsertSchema(poolStats).pick({
  totalHashrate: true,
  activeMiners: true,
  blocksFound: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertMiningStats = z.infer<typeof insertMiningStatsSchema>;
export type MiningStats = typeof miningStats.$inferSelect;

export type InsertPayout = z.infer<typeof insertPayoutSchema>;
export type Payout = typeof payouts.$inferSelect;

export type InsertPoolStats = z.infer<typeof insertPoolStatsSchema>;
export type PoolStats = typeof poolStats.$inferSelect;
