import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Progress } from "@/components/ui/progress";
import { formatHashrate } from "@/lib/mining";
import { useMining } from "@/contexts/mining-context";

export function CommunityPanel() {
  const { userHashrate } = useMining();

  // Fetch top miners data
  const { data: topMiners = [] } = useQuery({
    queryKey: ["/api/stats/miners/top"],
  });

  // Calculate max hashrate to normalize progress bars
  const maxHashrate = topMiners.length > 0 
    ? Math.max(...topMiners.map(miner => Number(miner.hashPower))) 
    : 1000;

  const userRanking = "#86 of 423"; // This would be fetched from API in a production app

  return (
    <Card className="bg-zinc-900 border-zinc-800 h-full">
      <CardHeader className="border-b border-zinc-800 p-5">
        <CardTitle className="text-lg font-medium text-gray-100">Pool Community</CardTitle>
      </CardHeader>
      <CardContent className="p-5">
        <p className="text-sm text-gray-500 mb-4">
          Top contributors in our mining community who help grow the network.
        </p>

        {/* Community leaderboard */}
        <div className="space-y-4">
          {topMiners.length > 0 ? (
            topMiners.map((miner, index) => (
              <div key={miner.id} className="flex items-center p-3 bg-zinc-800 rounded-lg">
                <div className={`bg-zinc-700 h-9 w-9 rounded-full flex items-center justify-center mr-3`}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className={`h-5 w-5 ${
                      index === 0 ? 'text-blue-500' : 
                      index === 1 ? 'text-amber-500' : 
                      'text-green-500'
                    }`}
                  >
                    <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
                    <circle cx="12" cy="7" r="4" />
                  </svg>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-baseline">
                    <span className="font-medium text-gray-100">{miner.username}</span>
                    <span className="text-xs text-gray-500">
                      {formatHashrate(Number(miner.hashPower))}
                    </span>
                  </div>
                  <Progress 
                    value={(Number(miner.hashPower) / maxHashrate) * 100} 
                    className="h-1.5 mt-1.5"
                  />
                </div>
              </div>
            ))
          ) : (
            // Placeholder data while loading
            Array.from({length: 3}).map((_, index) => (
              <div key={index} className="flex items-center p-3 bg-zinc-800 rounded-lg">
                <div className="bg-zinc-700 h-9 w-9 rounded-full flex items-center justify-center mr-3 animate-pulse"></div>
                <div className="flex-1">
                  <div className="flex justify-between items-baseline">
                    <div className="h-4 w-24 bg-zinc-700 rounded animate-pulse"></div>
                    <div className="h-3 w-16 bg-zinc-700 rounded animate-pulse"></div>
                  </div>
                  <div className="w-full bg-zinc-700 rounded-full h-1.5 mt-1.5 animate-pulse"></div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Your ranking */}
        <div className="mt-6 pt-4 border-t border-zinc-700">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-500">Your Ranking:</span>
            <span className="text-sm font-medium text-gray-100">{userRanking}</span>
          </div>

          <div className="flex items-center p-3 bg-zinc-700 rounded-lg mt-3">
            <div className="bg-blue-500/20 h-9 w-9 rounded-full flex items-center justify-center mr-3">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-5 w-5 text-blue-500"
              >
                <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-baseline">
                <span className="font-medium text-gray-100">You</span>
                <span className="text-xs text-gray-500">{formatHashrate(userHashrate)}</span>
              </div>
              <Progress value={15} className="h-1.5 mt-1.5" />
            </div>
          </div>

          <Button variant="outline" className="w-full mt-6 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-gray-100 border-zinc-700">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-4 w-4 mr-1.5"
            >
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
            <span>View All Members</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
