import React, { useState } from "react";
import { useMining } from "@/contexts/mining-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { formatHashrate } from "@/lib/mining";
import { Play, Pause, X, UserPlus, Users, ToggleLeft } from "lucide-react";

export function TestModePanel() {
  const {
    testUsers,
    addTestUser,
    removeTestUser,
    toggleTestUserMining,
    isTestMode,
    toggleTestMode
  } = useMining();
  
  const [newUsername, setNewUsername] = useState("");
  
  const handleAddUser = () => {
    if (newUsername.trim()) {
      addTestUser(newUsername.trim());
      setNewUsername("");
    }
  };
  
  if (!isTestMode) {
    return (
      <Card className="p-4 bg-slate-900 border-slate-800">
        <div className="flex flex-col items-center justify-center space-y-4">
          <div className="flex items-center space-x-2">
            <ToggleLeft className="h-5 w-5 text-slate-400" />
            <h3 className="text-lg font-medium">Test Mode</h3>
          </div>
          <p className="text-sm text-slate-400 text-center">
            Enable test mode to simulate multiple miners and see how the hashrate changes in real-time.
          </p>
          <Button 
            onClick={toggleTestMode}
            className="w-full"
          >
            Enable Test Mode
          </Button>
        </div>
      </Card>
    );
  }
  
  return (
    <Card className="p-4 bg-slate-900 border-slate-800">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Users className="h-5 w-5 text-blue-500" />
          <h3 className="text-lg font-medium">Test Miners</h3>
        </div>
        <div className="flex items-center space-x-2">
          <Label htmlFor="test-mode" className="text-sm">Test Mode</Label>
          <Switch 
            id="test-mode" 
            checked={isTestMode} 
            onCheckedChange={toggleTestMode} 
          />
        </div>
      </div>
      
      <p className="text-sm text-slate-400 mb-4">
        Add virtual miners to simulate a mining pool and see how they affect the network hashrate.
      </p>
      
      <div className="flex space-x-2 mb-4">
        <Input 
          placeholder="Friend's username" 
          value={newUsername}
          onChange={e => setNewUsername(e.target.value)}
          className="flex-1"
        />
        <Button onClick={handleAddUser} disabled={!newUsername.trim()}>
          <UserPlus className="h-4 w-4 mr-1" />
          Add
        </Button>
      </div>
      
      {testUsers.length > 0 ? (
        <div className="space-y-3">
          <Separator className="my-2 bg-slate-800" />
          {testUsers.map(user => (
            <div 
              key={user.id} 
              className="flex items-center justify-between bg-slate-800/50 p-2 rounded-md"
            >
              <div className="flex flex-col">
                <div className="flex items-center space-x-2">
                  <span className="font-medium">{user.username}</span>
                  <Badge variant={user.isActive ? "default" : "outline"} className="text-xs">
                    {user.isActive ? "Active" : "Inactive"}
                  </Badge>
                </div>
                <span className="text-xs text-slate-400">
                  {user.isActive ? formatHashrate(user.hashrate) : "Offline"}
                </span>
              </div>
              <div className="flex space-x-2">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => toggleTestUserMining(user.id)}
                  className="h-8 w-8"
                >
                  {user.isActive ? (
                    <Pause className="h-4 w-4" />
                  ) : (
                    <Play className="h-4 w-4" />
                  )}
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => removeTestUser(user.id)}
                  className="h-8 w-8 text-red-500 hover:text-red-600"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-4 text-slate-500">
          No test miners added yet
        </div>
      )}
    </Card>
  );
}