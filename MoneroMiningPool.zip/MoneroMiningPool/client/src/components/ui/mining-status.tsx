import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useMining } from "@/contexts/mining-context";
import { formatHashrate } from "@/lib/mining";

interface MiningStatusProps {
  userId: number;
}

export function MiningStatus({ userId }: MiningStatusProps) {
  const { 
    isMining, 
    startMining, 
    stopMining, 
    userHashrate, 
    poolHashrate, 
    setHashPower,
    dailyEarnings,
    weeklyEarnings,
    totalEarnings
  } = useMining();

  // Track CPU usage percent (simulation)
  const [cpuUsage, setCpuUsage] = useState(75);

  // Pool members count
  const [poolMembers, setPoolMembers] = useState(423);

  // Calculate user contribution percentage
  const userContribution = poolHashrate > 0 
    ? ((userHashrate / (poolHashrate * 1000)) * 100).toFixed(4) 
    : "0.0000";

  const handleToggleMining = () => {
    if (isMining) {
      stopMining(userId);
    } else {
      startMining(userId);
    }
  };

  // Simulate random fluctuations in CPU usage
  useEffect(() => {
    if (isMining) {
      const interval = setInterval(() => {
        setCpuUsage(prev => {
          const fluctuation = Math.random() * 10 - 5; // -5 to +5
          return Math.min(Math.max(prev + fluctuation, 60), 90); // Keep between 60-90%
        });
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [isMining]);

  // Simulated XMR price in USD
  const xmrPrice = 160.42;

  return (
    <div className="bg-zinc-900 rounded-lg p-5 mb-6 border border-zinc-800">
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h2 className="text-lg font-medium text-gray-100 mb-1">Sofestika Mining Status</h2>
          <div className="flex flex-wrap items-center">
            <div className="flex h-4 w-4 relative">
              {isMining ? (
                <>
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-50"></span>
                  <span className="relative inline-flex rounded-full h-4 w-4 bg-green-500"></span>
                </>
              ) : (
                <span className="relative inline-flex rounded-full h-4 w-4 bg-red-500"></span>
              )}
            </div>
            <span className={`ml-2 font-medium ${isMining ? 'text-green-500' : 'text-red-500'}`}>
              {isMining ? 'Active' : 'Inactive'}
            </span>
            <span className="ml-2 text-gray-500 text-sm whitespace-nowrap">• Last block found 5 minutes ago</span>
          </div>
        </div>
        <div className="mt-4 md:mt-0">
          <Button
            onClick={handleToggleMining}
            className={`px-6 py-2.5 ${
              isMining 
                ? 'bg-green-600 hover:bg-green-700' 
                : 'bg-blue-600 hover:bg-blue-700'
            } text-white rounded-md font-medium`}
          >
            {isMining ? 'Stop Mining' : 'Start Mining'}
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <Card className="bg-zinc-800 border-zinc-700">
          <div className="p-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-gray-500 text-sm mb-1">Your Hashrate</p>
                <div className="flex items-baseline">
                  <h3 className="text-xl font-bold text-gray-100">
                    {formatHashrate(userHashrate)}
                  </h3>
                  <span className="ml-2 text-green-500 text-xs">
                    +0.3 KH/s
                  </span>
                </div>
              </div>
              <div className="bg-zinc-700 p-2 rounded-lg">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5 text-blue-500"
                >
                  <rect x="4" y="4" width="16" height="16" rx="2" ry="2" />
                  <rect x="9" y="9" width="6" height="6" />
                  <line x1="9" y1="1" x2="9" y2="4" />
                  <line x1="15" y1="1" x2="15" y2="4" />
                  <line x1="9" y1="20" x2="9" y2="23" />
                  <line x1="15" y1="20" x2="15" y2="23" />
                  <line x1="20" y1="9" x2="23" y2="9" />
                  <line x1="20" y1="14" x2="23" y2="14" />
                  <line x1="1" y1="9" x2="4" y2="9" />
                  <line x1="1" y1="14" x2="4" y2="14" />
                </svg>
              </div>
            </div>
            <div className="mt-3">
              <Progress value={cpuUsage} className="h-2 bg-zinc-700" />
              <p className="text-gray-500 text-xs mt-1">
                {cpuUsage}% of your available computing power
              </p>
            </div>
          </div>
        </Card>
        
        <Card className="bg-zinc-800 border-zinc-700">
          <div className="p-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-gray-500 text-sm mb-1">Pool Hashrate</p>
                <div className="flex items-baseline">
                  <h3 className="text-xl font-bold text-gray-100">
                    {formatHashrate(poolHashrate * 1000)} {/* Convert MH/s to KH/s */}
                  </h3>
                  <span className="ml-2 text-green-500 text-xs">+2.3%</span>
                </div>
              </div>
              <div className="bg-zinc-700 p-2 rounded-lg">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5 text-amber-500"
                >
                  <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
              </div>
            </div>
            <div className="mt-3">
              <p className="text-gray-500 text-sm">
                Pool Members: <span className="text-gray-100 font-medium">{poolMembers}</span>
              </p>
              <p className="text-gray-500 text-sm mt-1">
                Your Contribution: <span className="text-gray-100 font-medium">{userContribution}%</span>
              </p>
            </div>
          </div>
        </Card>
        
        <Card className="bg-zinc-800 border-zinc-700">
          <div className="p-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-gray-500 text-sm mb-1">Earnings (24h)</p>
                <div className="flex items-baseline">
                  <h3 className="text-xl font-bold text-gray-100">{dailyEarnings.toFixed(5)} XMR</h3>
                  <span className="ml-2 text-amber-500 text-xs">
                    ≈ ${(dailyEarnings * xmrPrice).toFixed(2)}
                  </span>
                </div>
              </div>
              <div className="bg-zinc-700 p-2 rounded-lg">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5 text-green-500"
                >
                  <circle cx="12" cy="12" r="10" />
                  <line x1="12" y1="8" x2="12" y2="16" />
                  <line x1="8" y1="12" x2="16" y2="12" />
                </svg>
              </div>
            </div>
            <div className="mt-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">This Week:</span>
                <span className="text-gray-100 font-medium">{weeklyEarnings.toFixed(5)} XMR</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-gray-500">Total:</span>
                <span className="text-gray-100 font-medium">{totalEarnings.toFixed(5)} XMR</span>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
