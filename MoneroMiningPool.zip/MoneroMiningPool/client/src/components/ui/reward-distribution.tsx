import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";

interface RewardDistributionProps {
  userId: number;
}

export function RewardDistribution({ userId }: RewardDistributionProps) {
  // Define type for payout data
  interface Payout {
    id: number;
    userId: number;
    amount: number;
    status: string;
    transactionId?: string;
    timestamp: string;
  }

  // Fetch payouts data
  const { data: payoutsData = [] } = useQuery<Payout[]>({
    queryKey: [`/api/payouts/${userId}`],
  });

  // Default values until data is loaded
  const currentBalance = 0.00794;
  const paymentThreshold = 0.01;
  const paymentProgress = (currentBalance / paymentThreshold) * 100;

  return (
    <Card className="bg-zinc-900 border-zinc-800">
      <CardHeader className="border-b border-zinc-800 p-5">
        <CardTitle className="text-lg font-medium text-gray-100">Reward Distribution</CardTitle>
      </CardHeader>
      <CardContent className="p-5">
        <p className="text-sm text-gray-500 mb-4">
          Rewards are distributed among miners proportionally to their contributed hashpower. 
          Payouts occur automatically once thresholds are reached.
        </p>

        {/* Payment history */}
        <h3 className="text-md font-medium text-gray-200 mb-3">Recent Payments</h3>
        <div className="overflow-x-auto -mx-5 px-5">
          <Table className="min-w-full">
            <TableHeader className="bg-zinc-800">
              <TableRow className="border-zinc-700">
                <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider py-2">Date</TableHead>
                <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider py-2">Amount</TableHead>
                <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider py-2">Status</TableHead>
                <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider py-2">Transaction</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="bg-zinc-800 divide-y divide-zinc-700">
              {payoutsData && payoutsData.length > 0 ? (
                payoutsData.map((payout) => (
                  <TableRow key={payout.id}>
                    <TableCell className="whitespace-nowrap text-xs sm:text-sm text-gray-200 py-2">
                      {new Date(payout.timestamp).toLocaleString()}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-xs sm:text-sm text-gray-200 py-2">
                      {Number(payout.amount).toFixed(5)} XMR
                    </TableCell>
                    <TableCell className="whitespace-nowrap py-2">
                      <Badge 
                        variant={"secondary"}
                        className={`text-xs ${
                          payout.status === "completed" 
                            ? "bg-green-100 text-green-800" 
                            : "bg-amber-100 text-amber-800"
                        }`}
                      >
                        {payout.status.charAt(0).toUpperCase() + payout.status.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-xs sm:text-sm text-blue-500 hover:text-blue-400 cursor-pointer py-2">
                      {payout.transactionId ? 
                        payout.transactionId.substring(0, 3) + '...' + 
                        payout.transactionId.substring(payout.transactionId.length - 4) : 
                        'Pending'}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                // Placeholder data or empty state
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-4 text-gray-500">
                    {payoutsData?.length === 0 ? 
                      'No payment history available yet' : 
                      'Loading payment history...'}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {/* Payment settings */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="bg-zinc-800 border-zinc-700">
            <CardContent className="p-4">
              <h3 className="text-sm font-medium text-gray-200 mb-2">Payment Settings</h3>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Payment Threshold</span>
                <span className="text-sm text-gray-200">0.01 XMR</span>
              </div>
              <div className="flex items-center justify-between mt-2">
                <span className="text-sm text-gray-500">Payment Method</span>
                <span className="text-sm text-gray-200">Automatic</span>
              </div>
              <Button variant="outline" className="w-full mt-3 px-3 py-1.5 bg-zinc-700 hover:bg-zinc-600 text-gray-200 border-zinc-600 text-sm">Edit Settings</Button>
            </CardContent>
          </Card>

          <Card className="bg-zinc-800 border-zinc-700">
            <CardContent className="p-4">
              <h3 className="text-sm font-medium text-gray-200 mb-2">Next Payout</h3>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Current Balance</span>
                <span className="text-sm text-gray-200 font-medium">{currentBalance.toFixed(5)} XMR</span>
              </div>
              <div className="flex items-center justify-between mt-2">
                <span className="text-sm text-gray-500">Estimated Time</span>
                <span className="text-sm text-gray-200">~3 days</span>
              </div>
              <div className="mt-3">
                <Progress value={paymentProgress} className="h-2 bg-zinc-700" />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>0</span>
                  <span>0.01 XMR</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </CardContent>
    </Card>
  );
}
