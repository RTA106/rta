import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { getDailyPerformanceData, getWeeklyPerformanceData, getMonthlyPerformanceData } from "@/lib/chart-data";

interface MiningPerformanceProps {
  sharesAccepted: number;
  sharesRejected: number;
  avgHashrate: string;
  uptime: string;
}

export function MiningPerformance({
  sharesAccepted,
  sharesRejected,
  avgHashrate,
  uptime
}: MiningPerformanceProps) {
  const [period, setPeriod] = useState("day");
  const [dataType, setDataType] = useState("hashrate");

  // Get chart data based on the period
  const chartData = (() => {
    switch (period) {
      case "week":
        return getWeeklyPerformanceData(dataType);
      case "month":
        return getMonthlyPerformanceData(dataType);
      default:
        return getDailyPerformanceData(dataType);
    }
  })();

  // Determine chart color based on data type
  const chartColor = dataType === "earnings" ? "#10B981" : "#3B82F6";

  return (
    <Card className="bg-zinc-900 border-zinc-800 h-full">
      <CardHeader className="border-b border-zinc-800 p-5">
        <CardTitle className="text-lg font-medium text-gray-100">Mining Performance</CardTitle>
      </CardHeader>
      <CardContent className="p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <Tabs defaultValue="day" value={period} onValueChange={setPeriod} className="w-auto">
            <TabsList className="bg-zinc-800 h-9">
              <TabsTrigger value="day" className="data-[state=active]:bg-zinc-700 data-[state=active]:text-gray-100 h-8 px-3">
                Day
              </TabsTrigger>
              <TabsTrigger value="week" className="data-[state=active]:bg-zinc-700 data-[state=active]:text-gray-100 h-8 px-3">
                Week
              </TabsTrigger>
              <TabsTrigger value="month" className="data-[state=active]:bg-zinc-700 data-[state=active]:text-gray-100 h-8 px-3">
                Month
              </TabsTrigger>
            </TabsList>
          </Tabs>
          <Select value={dataType} onValueChange={setDataType}>
            <SelectTrigger className="bg-zinc-800 border-zinc-700 text-gray-400 rounded-md py-1 px-3 h-9 w-[120px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="hashrate">Hashrate</SelectItem>
              <SelectItem value="earnings">Earnings</SelectItem>
              <SelectItem value="shares">Shares</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="bg-zinc-800 rounded-lg p-4 h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorData" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={chartColor} stopOpacity={0.8} />
                  <stop offset="95%" stopColor={chartColor} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#383838" vertical={false} />
              <XAxis dataKey="name" tick={{ fill: '#9CA3AF' }} axisLine={{ stroke: '#383838' }} />
              <YAxis tick={{ fill: '#9CA3AF' }} axisLine={{ stroke: '#383838' }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1E1E1E', borderColor: '#383838' }}
                labelStyle={{ color: '#F3F4F6' }}
                itemStyle={{ color: chartColor }}
              />
              <Area
                type="monotone"
                dataKey="value"
                stroke={chartColor}
                fillOpacity={1}
                fill="url(#colorData)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          <div className="bg-zinc-800 p-3 rounded-lg">
            <p className="text-gray-500 text-xs">Shares Accepted</p>
            <p className="text-gray-100 font-medium mt-1">{sharesAccepted.toLocaleString()}</p>
          </div>
          <div className="bg-zinc-800 p-3 rounded-lg">
            <p className="text-gray-500 text-xs">Shares Rejected</p>
            <p className="text-gray-100 font-medium mt-1">{sharesRejected}</p>
          </div>
          <div className="bg-zinc-800 p-3 rounded-lg">
            <p className="text-gray-500 text-xs">Avg. Hashrate</p>
            <p className="text-gray-100 font-medium mt-1">{avgHashrate}</p>
          </div>
          <div className="bg-zinc-800 p-3 rounded-lg">
            <p className="text-gray-500 text-xs">Uptime</p>
            <p className="text-gray-100 font-medium mt-1">{uptime}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
