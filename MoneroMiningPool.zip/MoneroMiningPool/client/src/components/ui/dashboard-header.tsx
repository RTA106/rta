import { Button } from "@/components/ui/button";
import { CoinIcon } from "@/components/icons";
import { useQuery } from "@tanstack/react-query";

interface DashboardHeaderProps {
  onInviteFriends: () => void;
}

export function DashboardHeader({ onInviteFriends }: DashboardHeaderProps) {
  // Fetch current Monero price from API
  const { data: moneroPrice } = useQuery<any>({
    queryKey: ["https://api.coingecko.com/api/v3/simple/price?ids=monero&vs_currencies=usd"],
    staleTime: 60 * 1000, // 1 minute
  });

  // Use fallback price if API data isn't available
  const formattedPrice = "$160.42"; // Fallback value
  
  return (
    <div className="pb-5 border-b border-zinc-800 mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
      <div>
        <h1 className="text-2xl font-semibold text-white">Sofestika Dashboard</h1>
        <p className="text-zinc-400 text-sm mt-1">Distributed Monero Mining Pool</p>
      </div>
      <div className="mt-4 md:mt-0 flex flex-wrap items-center gap-3 sm:space-x-3">
        <div className="flex items-center text-amber-500 px-3 py-1.5 rounded-full bg-zinc-800">
          <CoinIcon className="mr-1.5 h-4 w-4" />
          <span className="text-sm font-medium">XMR: {formattedPrice}</span>
        </div>
        <Button 
          onClick={onInviteFriends}
          variant="default"
          type="button"
          size="default"
          className="w-full sm:w-auto px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md flex items-center justify-center touch-manipulation"
          style={{ WebkitTapHighlightColor: 'transparent' }}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 4v16m-8-8h16" />
          </svg>
          <span className="whitespace-nowrap">Invite Friends</span>
        </Button>
      </div>
    </div>
  );
}
