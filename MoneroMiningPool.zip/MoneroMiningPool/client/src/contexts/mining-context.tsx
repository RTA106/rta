import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { simulateHashrateFluctuation, calculateEarnings } from "@/lib/mining";
import { apiRequest } from "@/lib/queryClient";

interface TestUser {
  id: number;
  username: string;
  hashrate: number;
  isActive: boolean;
}

interface MiningContextProps {
  // Mining status
  isMining: boolean;
  startMining: (userId: number) => void;
  stopMining: (userId: number) => void;
  
  // Hashrate data
  userHashrate: number;
  poolHashrate: number;
  
  // Mining statistics
  sharesAccepted: number;
  sharesRejected: number;
  cpuThreads: number;
  setCPUThreads: (threads: number) => void;
  
  // Earnings data
  dailyEarnings: number;
  weeklyEarnings: number;
  totalEarnings: number;
  
  // Set hashrate manually (for simulation)
  setHashPower: (hashPower: number) => void;
  
  // Initialization status
  isInitialized: boolean;
  
  // Test users (friends) functionality
  testUsers: TestUser[];
  addTestUser: (username: string) => void;
  removeTestUser: (id: number) => void;
  toggleTestUserMining: (id: number) => void;
  isTestMode: boolean;
  toggleTestMode: () => void;
}

const MiningContext = createContext<MiningContextProps | undefined>(undefined);

interface MiningProviderProps {
  children: ReactNode;
}

export function MiningProvider({ children }: MiningProviderProps) {
  // Mining status
  const [isMining, setIsMining] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const [isTestMode, setIsTestMode] = useState(false);
  
  // Hashrate data
  const [userHashrate, setUserHashrate] = useState(0);
  const [poolHashrate, setPoolHashrate] = useState(156.78); // Initial pool hashrate in MH/s
  
  // Mining statistics
  const [sharesAccepted, setSharesAccepted] = useState(0);
  const [sharesRejected, setSharesRejected] = useState(0);
  const [cpuThreads, setCPUThreads] = useState(4);
  
  // Earnings data based on hashrate
  const [dailyEarnings, setDailyEarnings] = useState(0);
  const [weeklyEarnings, setWeeklyEarnings] = useState(0);
  const [totalEarnings, setTotalEarnings] = useState(0.12794);
  
  // Test users (friends)
  const [testUsers, setTestUsers] = useState<TestUser[]>([]);
  const [nextTestUserId, setNextTestUserId] = useState(100);
  const [testUserIntervals, setTestUserIntervals] = useState<{[key: number]: NodeJS.Timeout}>({});
  
  // Auto-increment interval ID
  const [hashUpdateInterval, setHashUpdateInterval] = useState<NodeJS.Timeout | null>(null);
  const [sharesUpdateInterval, setSharesUpdateInterval] = useState<NodeJS.Timeout | null>(null);
  
  // Detect CPU cores on initialization
  useEffect(() => {
    if (typeof navigator !== "undefined" && navigator.hardwareConcurrency) {
      setCPUThreads(Math.max(1, navigator.hardwareConcurrency - 1));
    }
    
    // Fetch initial pool statistics
    fetchPoolStats();
    
    // Mark context as initialized
    setIsInitialized(true);
    
    // Cleanup function for test users
    return () => {
      // Clear all test user intervals
      Object.values(testUserIntervals).forEach(interval => {
        clearInterval(interval);
      });
    };
  }, []);
  
  // Fetch pool statistics from the API
  const fetchPoolStats = async () => {
    try {
      const response = await fetch("/api/stats/pool");
      if (response.ok) {
        const data = await response.json();
        setPoolHashrate(Number(data.totalHashrate) / 1000); // Convert to MH/s
      }
    } catch (error) {
      console.error("Error fetching pool stats:", error);
    }
  };
  
  // Start mining - begin hash power simulation and API calls
  const startMining = async (userId: number) => {
    if (isMining) return;
    
    try {
      // Initial hashrate based on CPU threads (approximate values)
      const initialHashrate = cpuThreads * 600; // ~600 H/s per thread
      
      // Notify the server
      const response = await apiRequest("POST", "/api/mining/start", { 
        userId, 
        hashrate: initialHashrate 
      });
      
      if (response.ok) {
        setIsMining(true);
        setUserHashrate(initialHashrate);
        
        // Start hashrate fluctuation simulation
        const interval = setInterval(() => {
          setUserHashrate(prevHashrate => {
            const newHashrate = simulateHashrateFluctuation(prevHashrate, 0.05);
            
            // Update earnings based on new hashrate
            updateEarnings(newHashrate);
            
            return newHashrate;
          });
        }, 5000);
        
        setHashUpdateInterval(interval);
        
        // Start simulating shares accumulation
        const sharesInterval = setInterval(() => {
          const newShares = Math.floor(Math.random() * 10) + 5; // 5-15 shares per interval
          setSharesAccepted(prev => prev + newShares);
          
          // Occasionally add a rejected share
          if (Math.random() < 0.05) {
            setSharesRejected(prev => prev + 1);
          }
        }, 3000);
        
        setSharesUpdateInterval(sharesInterval);
        
        // Calculate initial earnings
        updateEarnings(initialHashrate);
      }
    } catch (error) {
      console.error("Error starting mining:", error);
    }
  };
  
  // Stop mining - clear intervals and reset state
  const stopMining = async (userId: number) => {
    if (!isMining) return;
    
    try {
      // Notify the server
      await apiRequest("POST", "/api/mining/stop", { userId });
      
      setIsMining(false);
      setUserHashrate(0);
      
      // Clear intervals
      if (hashUpdateInterval) {
        clearInterval(hashUpdateInterval);
        setHashUpdateInterval(null);
      }
      
      if (sharesUpdateInterval) {
        clearInterval(sharesUpdateInterval);
        setSharesUpdateInterval(null);
      }
      
      // Reset daily and weekly earnings
      setDailyEarnings(0);
      setWeeklyEarnings(0);
    } catch (error) {
      console.error("Error stopping mining:", error);
    }
  };
  
  // Update earnings based on current hashrate
  const updateEarnings = (hashrate: number) => {
    // Pool hashrate needs to be converted from MH/s to H/s for calculation
    const poolHashrateHs = poolHashrate * 1000000;
    
    // Calculate daily earnings
    const daily = calculateEarnings(hashrate, poolHashrateHs);
    setDailyEarnings(daily);
    
    // Weekly is approximately 7x daily
    setWeeklyEarnings(daily * 7);
  };
  
  // Set hash power manually (for simulation)
  const setHashPower = (hashPower: number) => {
    setUserHashrate(hashPower);
    updateEarnings(hashPower);
  };
  
  // Add test user (friend)
  const addTestUser = (username: string) => {
    const id = nextTestUserId;
    const initialHashrate = Math.floor(Math.random() * 2000) + 500; // Random hashrate between 500-2500 H/s
    
    const newUser: TestUser = {
      id,
      username,
      hashrate: initialHashrate,
      isActive: false
    };
    
    setTestUsers(prev => [...prev, newUser]);
    setNextTestUserId(prev => prev + 1);
    
    // Update pool hashrate
    updatePoolHashrate();
  };
  
  // Remove test user
  const removeTestUser = (id: number) => {
    // If user is active, stop mining first
    const user = testUsers.find(u => u.id === id);
    if (user && user.isActive) {
      stopTestUserMining(id);
    }
    
    setTestUsers(prev => prev.filter(user => user.id !== id));
    
    // Update pool hashrate
    updatePoolHashrate();
  };
  
  // Toggle test user mining status
  const toggleTestUserMining = (id: number) => {
    const user = testUsers.find(u => u.id === id);
    
    if (user) {
      if (user.isActive) {
        stopTestUserMining(id);
      } else {
        startTestUserMining(id);
      }
    }
  };
  
  // Start test user mining
  const startTestUserMining = (id: number) => {
    setTestUsers(prev => 
      prev.map(user => 
        user.id === id ? { ...user, isActive: true } : user
      )
    );
    
    // Create interval to simulate hashrate fluctuation
    const interval = setInterval(() => {
      setTestUsers(prev => 
        prev.map(user => {
          if (user.id === id) {
            const newHashrate = simulateHashrateFluctuation(user.hashrate, 0.08);
            return { ...user, hashrate: newHashrate };
          }
          return user;
        })
      );
      
      // Update pool hashrate whenever a user's hashrate changes
      updatePoolHashrate();
    }, 7000);
    
    // Store the interval
    setTestUserIntervals(prev => ({ ...prev, [id]: interval }));
    
    // Update pool hashrate immediately
    updatePoolHashrate();
  };
  
  // Stop test user mining
  const stopTestUserMining = (id: number) => {
    // Clear the interval
    if (testUserIntervals[id]) {
      clearInterval(testUserIntervals[id]);
      setTestUserIntervals(prev => {
        const newIntervals = { ...prev };
        delete newIntervals[id];
        return newIntervals;
      });
    }
    
    // Update user status
    setTestUsers(prev => 
      prev.map(user => 
        user.id === id ? { ...user, isActive: false, hashrate: 0 } : user
      )
    );
    
    // Update pool hashrate
    updatePoolHashrate();
  };
  
  // Update pool hashrate based on all active miners (user + test users)
  const updatePoolHashrate = () => {
    // Get base pool hashrate (excluding test users)
    let basePoolHashrate = 156780; // 156.78 MH/s in H/s
    
    // Add hashrate from active test users
    const testUserHashrate = testUsers.reduce((total, user) => {
      return user.isActive ? total + user.hashrate : total;
    }, 0);
    
    // Set new pool hashrate (convert back to MH/s for display)
    setPoolHashrate((basePoolHashrate + testUserHashrate) / 1000);
  };
  
  // Toggle test mode
  const toggleTestMode = () => {
    setIsTestMode(prev => !prev);
  };
  
  // Create context value
  const contextValue: MiningContextProps = {
    isMining,
    startMining,
    stopMining,
    userHashrate,
    poolHashrate,
    sharesAccepted,
    sharesRejected,
    cpuThreads,
    setCPUThreads,
    dailyEarnings,
    weeklyEarnings,
    totalEarnings,
    setHashPower,
    isInitialized,
    testUsers,
    addTestUser,
    removeTestUser,
    toggleTestUserMining,
    isTestMode,
    toggleTestMode
  };
  
  return (
    <MiningContext.Provider value={contextValue}>
      {children}
    </MiningContext.Provider>
  );
}

// Custom hook to use the mining context
export function useMining() {
  const context = useContext(MiningContext);
  if (context === undefined) {
    throw new Error("useMining must be used within a MiningProvider");
  }
  return context;
}
