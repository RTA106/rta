/**
 * Generate chart data for mining performance graphs
 */

// Daily performance data (24 hours)
export function getDailyPerformanceData(type: string = "hashrate") {
  const hours = Array.from({ length: 24 }, (_, i) => {
    const hour = i.toString().padStart(2, '0') + ':00';
    return hour;
  });

  // Base values depending on chart type
  let baseValue: number;
  switch (type) {
    case "earnings":
      baseValue = 0.00009; // Base XMR earnings per hour
      break;
    case "shares":
      baseValue = 600; // Base shares accepted per hour
      break;
    default: // hashrate
      baseValue = 2.4; // Base KH/s
      break;
  }

  return hours.map((name, index) => {
    // Create realistic daily pattern with higher values during night hours
    // and lower during typical working hours
    let modifier = 1;
    
    // Late night/early morning (higher hashrate when computer is idle)
    if (index >= 0 && index < 6) {
      modifier = 1.2;
    } 
    // Morning/work hours (lower hashrate due to computer usage)
    else if (index >= 8 && index < 17) {
      modifier = 0.85;
    }
    // Evening (medium hashrate)
    else {
      modifier = 1;
    }
    
    // Add some randomness
    const randomFactor = 0.9 + Math.random() * 0.3;
    const finalValue = baseValue * modifier * randomFactor;
    
    return {
      name,
      value: type === "hashrate" ? parseFloat(finalValue.toFixed(2)) :
             type === "earnings" ? parseFloat(finalValue.toFixed(5)) :
             Math.round(finalValue) // For shares
    };
  });
}

// Weekly performance data (7 days)
export function getWeeklyPerformanceData(type: string = "hashrate") {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  
  // Base values depending on chart type
  let baseValue: number;
  switch (type) {
    case "earnings":
      baseValue = 0.00219; // Base XMR earnings per day
      break;
    case "shares":
      baseValue = 14400; // Base shares accepted per day
      break;
    default: // hashrate
      baseValue = 2.4; // Base KH/s
      break;
  }

  return days.map(name => {
    // Weekend has higher hashrate (people tend to leave computers on)
    const isWeekend = name === 'Sat' || name === 'Sun';
    const modifier = isWeekend ? 1.2 : 1;
    
    // Add some randomness
    const randomFactor = 0.9 + Math.random() * 0.3;
    const finalValue = baseValue * modifier * randomFactor;
    
    return {
      name,
      value: type === "hashrate" ? parseFloat(finalValue.toFixed(2)) :
             type === "earnings" ? parseFloat(finalValue.toFixed(5)) :
             Math.round(finalValue) // For shares
    };
  });
}

// Monthly performance data (30 days)
export function getMonthlyPerformanceData(type: string = "hashrate") {
  // Generate days 1-30
  const days = Array.from({ length: 30 }, (_, i) => `${i + 1}`);
  
  // Base values depending on chart type
  let baseValue: number;
  switch (type) {
    case "earnings":
      baseValue = 0.00219; // Base XMR earnings per day
      break;
    case "shares":
      baseValue = 14400; // Base shares accepted per day
      break;
    default: // hashrate
      baseValue = 2.4; // Base KH/s
      break;
  }

  return days.map((name, index) => {
    // Add some random trends over the month
    // First third of month: steady
    // Middle: slight increase (optimization)
    // Last third: higher (upgraded hardware scenario)
    let modifier = 1;
    
    if (index < 10) {
      modifier = 1;
    } else if (index < 20) {
      modifier = 1.1;
    } else {
      modifier = 1.25;
    }
    
    // Add some randomness
    const randomFactor = 0.9 + Math.random() * 0.3;
    const finalValue = baseValue * modifier * randomFactor;
    
    return {
      name,
      value: type === "hashrate" ? parseFloat(finalValue.toFixed(2)) :
             type === "earnings" ? parseFloat(finalValue.toFixed(5)) :
             Math.round(finalValue) // For shares
    };
  });
}

// Generate data for hardware utilization pie chart
export function getHardwareUtilizationData() {
  return [
    { name: "CPU", value: 85 },
    { name: "Memory", value: 45 },
    { name: "Disk I/O", value: 20 },
    { name: "Network", value: 30 },
  ];
}

// Generate data for earnings breakdown pie chart
export function getEarningsBreakdownData() {
  return [
    { name: "Mining Rewards", value: 85 },
    { name: "Referral Bonus", value: 10 },
    { name: "Pool Bonus", value: 5 },
  ];
}
