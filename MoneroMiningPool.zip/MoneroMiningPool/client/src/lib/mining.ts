/**
 * Helper functions for mining operations and calculations
 */

/**
 * Format hashrate to appropriate units (H/s, KH/s, MH/s, GH/s)
 * @param hashrate - The hashrate in H/s
 * @returns Formatted hashrate string
 */
export function formatHashrate(hashrate: number): string {
  if (hashrate === 0) return "0 H/s";
  
  if (hashrate < 1000) {
    return `${hashrate.toFixed(2)} H/s`;
  } else if (hashrate < 1000000) {
    return `${(hashrate / 1000).toFixed(2)} KH/s`;
  } else if (hashrate < 1000000000) {
    return `${(hashrate / 1000000).toFixed(2)} MH/s`;
  } else {
    return `${(hashrate / 1000000000).toFixed(2)} GH/s`;
  }
}

/**
 * Calculate expected earnings based on hashrate, pool hashrate, and block reward
 * @param hashrate - User's hashrate in H/s
 * @param poolHashrate - Total pool hashrate in H/s
 * @param blockReward - Block reward in XMR
 * @param blocksPerDay - Average number of blocks found per day
 * @returns Daily estimated earnings in XMR
 */
export function calculateEarnings(
  hashrate: number,
  poolHashrate: number,
  blockReward: number = 2.1,
  blocksPerDay: number = 10
): number {
  if (poolHashrate === 0 || hashrate === 0) return 0;
  
  const userShare = hashrate / poolHashrate;
  const dailyReward = blockReward * blocksPerDay;
  return userShare * dailyReward;
}

/**
 * Simulate the varying hashrate for a mining session to create realistic fluctuations
 * @param baseHashrate - Base hashrate in H/s
 * @param fluctuationRange - Range of fluctuation as a percentage (0-1)
 * @returns New hashrate with random fluctuation
 */
export function simulateHashrateFluctuation(
  baseHashrate: number,
  fluctuationRange: number = 0.05
): number {
  if (baseHashrate === 0) return 0;
  
  // Generate a random fluctuation between -range and +range
  const fluctuation = (Math.random() * 2 - 1) * fluctuationRange;
  const newHashrate = baseHashrate * (1 + fluctuation);
  
  // Ensure we don't return negative values
  return Math.max(newHashrate, 0);
}

/**
 * Calculate the user's contribution percentage to the pool
 * @param userHashrate - User's hashrate in H/s
 * @param poolHashrate - Total pool hashrate in H/s
 * @returns Contribution percentage
 */
export function calculateContribution(userHashrate: number, poolHashrate: number): number {
  if (poolHashrate === 0 || userHashrate === 0) return 0;
  return (userHashrate / poolHashrate) * 100;
}

/**
 * Estimate time until the next payout based on current balance and daily earnings
 * @param currentBalance - Current balance in XMR
 * @param dailyEarnings - Daily earnings in XMR
 * @param payoutThreshold - Payout threshold in XMR
 * @returns Estimated days until payout
 */
export function estimateDaysUntilPayout(
  currentBalance: number,
  dailyEarnings: number,
  payoutThreshold: number = 0.01
): number {
  if (dailyEarnings === 0 || currentBalance >= payoutThreshold) return 0;
  const remaining = payoutThreshold - currentBalance;
  return remaining / dailyEarnings;
}

/**
 * Check if the system's hardware is suitable for mining
 * @param cpuCores - Number of CPU cores
 * @param memoryGB - Amount of system memory in GB
 * @returns Object with suitability assessment
 */
export function checkHardwareSuitability(cpuCores: number, memoryGB: number): {
  suitable: boolean;
  recommendedThreads: number;
  message: string;
} {
  // Basic hardware checks
  if (cpuCores <= 1) {
    return {
      suitable: false,
      recommendedThreads: 0,
      message: "CPU does not have enough cores for effective mining"
    };
  }
  
  if (memoryGB < 4) {
    return {
      suitable: false,
      recommendedThreads: 0,
      message: "Not enough system memory for RandomX mining"
    };
  }
  
  // Leave at least 1 core free for system operations
  const recommendedThreads = Math.max(1, cpuCores - 1);
  
  if (cpuCores < 4) {
    return {
      suitable: true,
      recommendedThreads,
      message: "System can mine, but performance will be limited"
    };
  }
  
  return {
    suitable: true,
    recommendedThreads,
    message: "System is suitable for mining"
  };
}

/**
 * Detect the optimal number of threads for the current system
 * @returns Number of threads to use
 */
export function detectOptimalThreads(): number {
  // In a browser environment, use navigator.hardwareConcurrency if available
  if (typeof navigator !== "undefined" && navigator.hardwareConcurrency) {
    return Math.max(1, navigator.hardwareConcurrency - 1);
  }
  
  // Default fallback
  return 4;
}
