import { Sidebar } from "@/components/ui/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { useMining } from "@/contexts/mining-context";
import { useState } from "react";

export default function Settings() {
  const { toast } = useToast();
  const { cpuThreads, setCPUThreads } = useMining();
  
  const [username, setUsername] = useState("User428765");
  const [walletAddress, setWalletAddress] = useState("4BrL51JCc9NGQ71kWhnYoDRffsDZy7m1HUU7MRU4nUMXAHNFBEJhkTZV9HdaL4gfuNBxLPc3BeMkLGaPbF5vWtANQs4pDSFQgLM");

  // CPU cores for the sliders (simulated)
  const maxCores = 12;
  
  const handleSaveProfile = () => {
    toast({
      title: "Profile Updated",
      description: "Your profile information has been saved",
      duration: 3000,
    });
  };

  const handleSaveMiningSettings = () => {
    toast({
      title: "Mining Settings Updated",
      description: "Your mining configuration has been updated",
      duration: 3000,
    });
  };

  const handleSaveNotifications = () => {
    toast({
      title: "Notification Preferences Saved",
      description: "Your notification settings have been updated",
      duration: 3000,
    });
  };

  return (
    <div className="flex h-screen overflow-hidden bg-zinc-950 text-gray-100">
      <Sidebar />

      <div className="flex-1 md:pl-64 pt-16 md:pt-0">
        <main className="h-full overflow-y-auto pb-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 py-6">
            <div className="pb-5 border-b border-zinc-800 mb-6">
              <h1 className="text-2xl font-semibold text-white">Settings</h1>
            </div>

            <Tabs defaultValue="account" className="space-y-6">
              <TabsList className="bg-zinc-800 w-full md:w-auto p-1 justify-start">
                <TabsTrigger value="account" className="data-[state=active]:bg-zinc-700 px-6">
                  Account
                </TabsTrigger>
                <TabsTrigger value="mining" className="data-[state=active]:bg-zinc-700 px-6">
                  Mining
                </TabsTrigger>
                <TabsTrigger value="notifications" className="data-[state=active]:bg-zinc-700 px-6">
                  Notifications
                </TabsTrigger>
                <TabsTrigger value="security" className="data-[state=active]:bg-zinc-700 px-6">
                  Security
                </TabsTrigger>
              </TabsList>

              {/* Account Settings Tab */}
              <TabsContent value="account">
                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader className="border-b border-zinc-800">
                    <CardTitle className="text-lg text-gray-100">Account Information</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="username" className="block text-sm text-gray-400 mb-1">
                            Username
                          </Label>
                          <Input 
                            id="username" 
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            className="bg-zinc-800 border-zinc-700 text-gray-300"
                          />
                        </div>
                        <div>
                          <Label htmlFor="email" className="block text-sm text-gray-400 mb-1">
                            Email Address
                          </Label>
                          <Input 
                            id="email" 
                            type="email" 
                            placeholder="your.email@example.com" 
                            className="bg-zinc-800 border-zinc-700 text-gray-300"
                          />
                          <p className="text-xs text-gray-500 mt-1">
                            Used for important notifications and account recovery
                          </p>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="wallet" className="block text-sm text-gray-400 mb-1">
                          Monero Wallet Address
                        </Label>
                        <Input 
                          id="wallet" 
                          value={walletAddress} 
                          onChange={(e) => setWalletAddress(e.target.value)}
                          className="bg-zinc-800 border-zinc-700 text-gray-300 font-mono text-xs"
                        />
                        <p className="text-xs text-gray-500 mt-1">
                          Your mining rewards will be sent to this address
                        </p>
                      </div>

                      <div className="border-t border-zinc-800 pt-6">
                        <Button 
                          onClick={handleSaveProfile}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          Save Changes
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Mining Settings Tab */}
              <TabsContent value="mining">
                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader className="border-b border-zinc-800">
                    <CardTitle className="text-lg text-gray-100">Mining Configuration</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-sm font-medium text-gray-200 mb-2">CPU Mining</h3>
                        <div className="space-y-4">
                          <div>
                            <div className="flex justify-between items-center mb-2">
                              <Label htmlFor="cpu-threads" className="text-sm text-gray-400">
                                CPU Threads
                              </Label>
                              <span className="text-sm font-medium text-gray-300">{cpuThreads} / {maxCores}</span>
                            </div>
                            <Slider 
                              id="cpu-threads" 
                              min={1} 
                              max={maxCores} 
                              step={1} 
                              value={[cpuThreads]} 
                              onValueChange={(value) => setCPUThreads(value[0])}
                              className="w-full" 
                            />
                            <p className="text-xs text-gray-500 mt-1">
                              Adjust the number of CPU threads used for mining. More threads = higher hashrate but may affect system performance.
                            </p>
                          </div>

                          <div>
                            <div className="flex justify-between items-center mb-2">
                              <Label htmlFor="cpu-priority" className="text-sm text-gray-400">
                                CPU Priority
                              </Label>
                              <span className="text-sm font-medium text-gray-300">Medium</span>
                            </div>
                            <Slider 
                              id="cpu-priority" 
                              min={1} 
                              max={5} 
                              step={1} 
                              defaultValue={[3]} 
                              className="w-full" 
                            />
                            <p className="text-xs text-gray-500 mt-1">
                              Lower priority = less impact on system, higher priority = better mining performance
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="border-t border-zinc-800 pt-6">
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <div>
                              <Label htmlFor="auto-start" className="text-sm font-medium text-gray-300">
                                Auto-start Mining
                              </Label>
                              <p className="text-xs text-gray-500">
                                Automatically start mining when the application launches
                              </p>
                            </div>
                            <Switch id="auto-start" />
                          </div>

                          <div className="flex items-center justify-between">
                            <div>
                              <Label htmlFor="idle-mining" className="text-sm font-medium text-gray-300">
                                Idle Mining
                              </Label>
                              <p className="text-xs text-gray-500">
                                Only mine when your system is idle
                              </p>
                            </div>
                            <Switch id="idle-mining" defaultChecked />
                          </div>

                          <div className="flex items-center justify-between">
                            <div>
                              <Label htmlFor="power-saving" className="text-sm font-medium text-gray-300">
                                Power Saving Mode
                              </Label>
                              <p className="text-xs text-gray-500">
                                Reduce mining intensity when on battery power
                              </p>
                            </div>
                            <Switch id="power-saving" defaultChecked />
                          </div>
                        </div>
                      </div>

                      <div className="border-t border-zinc-800 pt-6">
                        <h3 className="text-sm font-medium text-gray-200 mb-2">Pool Configuration</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                            <Label htmlFor="pool-address" className="block text-sm text-gray-400 mb-1">
                              Mining Pool Address
                            </Label>
                            <Input 
                              id="pool-address" 
                              value="pool.hashshare.io:3333" 
                              readOnly
                              className="bg-zinc-800 border-zinc-700 text-gray-300"
                            />
                          </div>
                          <div>
                            <Label htmlFor="pool-password" className="block text-sm text-gray-400 mb-1">
                              Worker Name (optional)
                            </Label>
                            <Input 
                              id="pool-password" 
                              placeholder="e.g. worker1" 
                              className="bg-zinc-800 border-zinc-700 text-gray-300"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="border-t border-zinc-800 pt-6">
                        <Button 
                          onClick={handleSaveMiningSettings}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          Save Mining Settings
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Notifications Tab */}
              <TabsContent value="notifications">
                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader className="border-b border-zinc-800">
                    <CardTitle className="text-lg text-gray-100">Notification Preferences</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-6">
                      <div className="space-y-3">
                        <h3 className="text-sm font-medium text-gray-200 mb-2">Email Notifications</h3>

                        <div className="flex items-center justify-between">
                          <div>
                            <Label htmlFor="notify-payments" className="text-sm font-medium text-gray-300">
                              Payment Receipts
                            </Label>
                            <p className="text-xs text-gray-500">
                              Receive notifications when payments are sent to your wallet
                            </p>
                          </div>
                          <Switch id="notify-payments" defaultChecked />
                        </div>

                        <div className="flex items-center justify-between">
                          <div>
                            <Label htmlFor="notify-pool" className="text-sm font-medium text-gray-300">
                              Pool Updates
                            </Label>
                            <p className="text-xs text-gray-500">
                              News about pool maintenance, updates, and important changes
                            </p>
                          </div>
                          <Switch id="notify-pool" defaultChecked />
                        </div>

                        <div className="flex items-center justify-between">
                          <div>
                            <Label htmlFor="notify-rewards" className="text-sm font-medium text-gray-300">
                              Reward Milestones
                            </Label>
                            <p className="text-xs text-gray-500">
                              Notifications when you reach certain mining reward thresholds
                            </p>
                          </div>
                          <Switch id="notify-rewards" />
                        </div>
                      </div>

                      <div className="border-t border-zinc-800 pt-6 space-y-3">
                        <h3 className="text-sm font-medium text-gray-200 mb-2">Application Notifications</h3>

                        <div className="flex items-center justify-between">
                          <div>
                            <Label htmlFor="notify-status" className="text-sm font-medium text-gray-300">
                              Mining Status
                            </Label>
                            <p className="text-xs text-gray-500">
                              Notifications about mining status changes (starting, stopping, errors)
                            </p>
                          </div>
                          <Switch id="notify-status" defaultChecked />
                        </div>

                        <div className="flex items-center justify-between">
                          <div>
                            <Label htmlFor="notify-hashrate" className="text-sm font-medium text-gray-300">
                              Hashrate Alerts
                            </Label>
                            <p className="text-xs text-gray-500">
                              Notifications for significant changes in your mining hashrate
                            </p>
                          </div>
                          <Switch id="notify-hashrate" defaultChecked />
                        </div>

                        <div className="flex items-center justify-between">
                          <div>
                            <Label htmlFor="notify-blocks" className="text-sm font-medium text-gray-300">
                              Block Notifications
                            </Label>
                            <p className="text-xs text-gray-500">
                              Get notified when the pool finds a new block
                            </p>
                          </div>
                          <Switch id="notify-blocks" />
                        </div>
                      </div>

                      <div className="border-t border-zinc-800 pt-6">
                        <Button 
                          onClick={handleSaveNotifications}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          Save Notification Preferences
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Security Tab */}
              <TabsContent value="security">
                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader className="border-b border-zinc-800">
                    <CardTitle className="text-lg text-gray-100">Security Settings</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-sm font-medium text-gray-200 mb-2">Change Password</h3>
                        <div className="space-y-3">
                          <div>
                            <Label htmlFor="current-password" className="block text-sm text-gray-400 mb-1">
                              Current Password
                            </Label>
                            <Input 
                              id="current-password" 
                              type="password" 
                              className="bg-zinc-800 border-zinc-700 text-gray-300"
                            />
                          </div>
                          <div>
                            <Label htmlFor="new-password" className="block text-sm text-gray-400 mb-1">
                              New Password
                            </Label>
                            <Input 
                              id="new-password" 
                              type="password" 
                              className="bg-zinc-800 border-zinc-700 text-gray-300"
                            />
                          </div>
                          <div>
                            <Label htmlFor="confirm-password" className="block text-sm text-gray-400 mb-1">
                              Confirm New Password
                            </Label>
                            <Input 
                              id="confirm-password" 
                              type="password" 
                              className="bg-zinc-800 border-zinc-700 text-gray-300"
                            />
                          </div>
                          <Button className="mt-2 bg-blue-600 hover:bg-blue-700">
                            Change Password
                          </Button>
                        </div>
                      </div>

                      <div className="border-t border-zinc-800 pt-6">
                        <h3 className="text-sm font-medium text-gray-200 mb-2">Two-Factor Authentication</h3>
                        <p className="text-sm text-gray-400 mb-3">
                          Protect your account with an additional layer of security
                        </p>
                        <Button className="bg-green-600 hover:bg-green-700">
                          Enable Two-Factor Authentication
                        </Button>
                      </div>

                      <div className="border-t border-zinc-800 pt-6">
                        <h3 className="text-sm font-medium text-gray-200 mb-2">Session Management</h3>
                        <p className="text-sm text-gray-400 mb-3">
                          Manage your active sessions and sign out from other devices
                        </p>
                        <div className="bg-zinc-800 p-4 rounded-lg mb-3">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-sm font-medium text-gray-200">Current Session</p>
                              <p className="text-xs text-gray-500">Windows 10 • Chrome • 192.168.1.1</p>
                              <p className="text-xs text-gray-500">Started: Today, 15:30</p>
                            </div>
                            <div className="bg-green-500/20 px-2 py-1 rounded text-green-400 text-xs">
                              Active
                            </div>
                          </div>
                        </div>
                        <Button variant="destructive" className="bg-red-600 hover:bg-red-700">
                          Sign Out All Other Devices
                        </Button>
                      </div>

                      <div className="border-t border-zinc-800 pt-6">
                        <h3 className="text-sm font-medium text-red-400 mb-2">Danger Zone</h3>
                        <p className="text-sm text-gray-400 mb-3">
                          These actions cannot be undone. Proceed with caution.
                        </p>
                        <div className="space-y-3">
                          <Button variant="outline" className="border-red-800 text-red-400 hover:text-red-300 hover:bg-red-950/50 hover:border-red-700">
                            Reset Mining Statistics
                          </Button>
                          <Button variant="outline" className="border-red-800 text-red-400 hover:text-red-300 hover:bg-red-950/50 hover:border-red-700">
                            Delete Account
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}
