import { Sidebar } from "@/components/ui/sidebar";
import { DashboardHeader } from "@/components/ui/dashboard-header";
import { MiningStatus } from "@/components/ui/mining-status";
import { MiningPerformance } from "@/components/ui/mining-performance";
import { CommunityPanel } from "@/components/ui/community-panel";
import { RewardDistribution } from "@/components/ui/reward-distribution";
import { EducationalInfo } from "@/components/ui/educational-info";
import { TestModePanel } from "@/components/ui/test-mode-panel";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";
import { useMining } from "@/contexts/mining-context";

export default function Dashboard() {
  const { toast } = useToast();
  const { isInitialized } = useMining();

  // For demo purposes, using a hardcoded user ID
  const userId = 1;

  const handleInviteFriends = () => {
    // Use a longer duration on mobile for better readability
    const isMobileDevice = window.innerWidth < 768;
    const duration = isMobileDevice ? 5000 : 3000;
    
    toast({
      title: "Invite Link Generated",
      description: "Share this link with friends to join your mining pool: sofestika.pool/invite/38f9d2",
      duration: duration,
    });
    
    // Vibrate on mobile devices for tactile feedback if supported
    if (isMobileDevice && navigator.vibrate) {
      navigator.vibrate(100);
    }
  };

  useEffect(() => {
    // Show welcome message on first load
    if (isInitialized) {
      toast({
        title: "Welcome to Sofestika",
        description: "Your distributed Monero mining dashboard is ready.",
        duration: 5000,
      });
    }
  }, [isInitialized, toast]);

  return (
    <div className="flex h-screen overflow-hidden bg-zinc-950 text-gray-100">
      <Sidebar />

      <div className="flex-1 md:pl-64 pt-16 md:pt-0">
        <main className="h-full overflow-y-auto pb-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 py-6">
            {/* Page header */}
            <DashboardHeader onInviteFriends={handleInviteFriends} />

            {/* Mining status */}
            <MiningStatus userId={userId} />

            {/* Mining Rewards & Statistics Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <MiningPerformance
                  sharesAccepted={14328}
                  sharesRejected={26}
                  avgHashrate="2.38 KH/s"
                  uptime="18h 42m"
                />
              </div>
              <div className="lg:col-span-1">
                <CommunityPanel />
              </div>
            </div>

            {/* Reward Distribution & Educational Info */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
              <div className="lg:col-span-2">
                <RewardDistribution userId={userId} />
              </div>
              <div className="lg:col-span-1">
                <div className="space-y-6">
                  <TestModePanel />
                  <EducationalInfo />
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
