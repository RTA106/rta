import { Sidebar } from "@/components/ui/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Help() {
  const { toast } = useToast();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Search Started",
      description: "Searching the knowledge base...",
      duration: 3000,
    });
  };

  return (
    <div className="flex h-screen overflow-hidden bg-zinc-950 text-gray-100">
      <Sidebar />

      <div className="flex-1 md:pl-64 pt-16 md:pt-0">
        <main className="h-full overflow-y-auto pb-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 py-6">
            <div className="pb-5 border-b border-zinc-800 mb-6">
              <h1 className="text-2xl font-semibold text-white">Help & Guides</h1>
            </div>

            {/* Search Section */}
            <Card className="bg-zinc-900 border-zinc-800 mb-6">
              <CardContent className="p-6">
                <h2 className="text-xl font-medium text-gray-100 mb-3">How can we help you?</h2>
                <form onSubmit={handleSearch} className="flex gap-2">
                  <Input 
                    placeholder="Search for mining guides, troubleshooting, FAQs..." 
                    className="bg-zinc-800 border-zinc-700 text-gray-300 flex-1"
                  />
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    Search
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Main Content */}
            <Tabs defaultValue="guides" className="space-y-6">
              <TabsList className="bg-zinc-800 p-1 justify-start">
                <TabsTrigger value="guides" className="data-[state=active]:bg-zinc-700 px-6">
                  Guides
                </TabsTrigger>
                <TabsTrigger value="faq" className="data-[state=active]:bg-zinc-700 px-6">
                  FAQ
                </TabsTrigger>
                <TabsTrigger value="troubleshooting" className="data-[state=active]:bg-zinc-700 px-6">
                  Troubleshooting
                </TabsTrigger>
                <TabsTrigger value="contact" className="data-[state=active]:bg-zinc-700 px-6">
                  Contact Support
                </TabsTrigger>
              </TabsList>

              {/* Guides Tab */}
              <TabsContent value="guides">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                  <Card className="bg-zinc-900 border-zinc-800">
                    <CardContent className="p-6 flex flex-col items-center text-center">
                      <div className="bg-blue-500/20 p-4 rounded-full mb-4">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="h-6 w-6 text-blue-500"
                        >
                          <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
                          <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
                        </svg>
                      </div>
                      <h3 className="text-lg font-medium text-gray-100 mb-2">Getting Started</h3>
                      <p className="text-sm text-gray-400 mb-4">
                        Learn the basics of Monero mining and how to set up Sofestika for optimal performance.
                      </p>
                      <Button variant="outline" className="border-zinc-700 text-gray-300 hover:bg-zinc-800 hover:text-gray-100 mt-auto">
                        Read Guide
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-zinc-900 border-zinc-800">
                    <CardContent className="p-6 flex flex-col items-center text-center">
                      <div className="bg-green-500/20 p-4 rounded-full mb-4">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="h-6 w-6 text-green-500"
                        >
                          <path d="M14 9a2 2 0 0 1-2 2H6l-4 4V4c0-1.1.9-2 2-2h8a2 2 0 0 1 2 2v5Z" />
                          <path d="M18 9h2a2 2 0 0 1 2 2v11l-4-4h-6a2 2 0 0 1-2-2v-1" />
                        </svg>
                      </div>
                      <h3 className="text-lg font-medium text-gray-100 mb-2">Pool Mining Tutorial</h3>
                      <p className="text-sm text-gray-400 mb-4">
                        Discover how pool mining works and how rewards are distributed in the Sofestika network.
                      </p>
                      <Button variant="outline" className="border-zinc-700 text-gray-300 hover:bg-zinc-800 hover:text-gray-100 mt-auto">
                        Read Guide
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-zinc-900 border-zinc-800">
                    <CardContent className="p-6 flex flex-col items-center text-center">
                      <div className="bg-amber-500/20 p-4 rounded-full mb-4">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="h-6 w-6 text-amber-500"
                        >
                          <path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z" />
                        </svg>
                      </div>
                      <h3 className="text-lg font-medium text-gray-100 mb-2">Optimization Tips</h3>
                      <p className="text-sm text-gray-400 mb-4">
                        Learn how to maximize your mining efficiency and boost your hashrate with these tips.
                      </p>
                      <Button variant="outline" className="border-zinc-700 text-gray-300 hover:bg-zinc-800 hover:text-gray-100 mt-auto">
                        Read Guide
                      </Button>
                    </CardContent>
                  </Card>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <Card className="bg-zinc-900 border-zinc-800">
                    <CardHeader className="border-b border-zinc-800">
                      <CardTitle className="text-lg text-gray-100">Hardware Recommendations</CardTitle>
                    </CardHeader>
                    <CardContent className="p-6">
                      <p className="text-sm text-gray-400 mb-4">
                        Monero uses the RandomX algorithm which is optimized for CPU mining. Here are some hardware recommendations:
                      </p>
                      <h3 className="text-md font-medium text-gray-200 mb-2">Recommended CPUs</h3>
                      <ul className="list-disc list-inside text-sm text-gray-400 space-y-1 mb-4">
                        <li>AMD Ryzen 9 series (3900X, 5900X)</li>
                        <li>AMD Ryzen 7 series (3700X, 5800X)</li>
                        <li>AMD EPYC server processors</li>
                        <li>Intel Core i9 series</li>
                        <li>Intel Core i7 series</li>
                      </ul>
                      <h3 className="text-md font-medium text-gray-200 mb-2">Memory Requirements</h3>
                      <p className="text-sm text-gray-400 mb-4">
                        RandomX is memory-hard, so having fast RAM with sufficient capacity is important:
                      </p>
                      <ul className="list-disc list-inside text-sm text-gray-400 space-y-1">
                        <li>Minimum: 8GB DDR4</li>
                        <li>Recommended: 16GB DDR4-3200 or better</li>
                        <li>Optimal: Dual-channel memory configuration</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="bg-zinc-900 border-zinc-800">
                    <CardHeader className="border-b border-zinc-800">
                      <CardTitle className="text-lg text-gray-100">Understanding Monero Mining</CardTitle>
                    </CardHeader>
                    <CardContent className="p-6">
                      <p className="text-sm text-gray-400 mb-4">
                        Monero (XMR) is a privacy-focused cryptocurrency that uses the RandomX proof-of-work algorithm.
                      </p>
                      <h3 className="text-md font-medium text-gray-200 mb-2">Key Mining Concepts</h3>
                      <ul className="list-disc list-inside text-sm text-gray-400 space-y-2">
                        <li>
                          <span className="text-gray-200">Hashrate:</span> The computational power you contribute, measured in hashes per second (H/s, KH/s, MH/s).
                        </li>
                        <li>
                          <span className="text-gray-200">Block:</span> A collection of transactions that miners work to verify and add to the blockchain.
                        </li>
                        <li>
                          <span className="text-gray-200">Pool Mining:</span> Miners combine their hashrate to find blocks faster and share rewards proportionally.
                        </li>
                        <li>
                          <span className="text-gray-200">Difficulty:</span> A network-wide setting that controls how hard it is to find a valid block.
                        </li>
                        <li>
                          <span className="text-gray-200">Reward Distribution:</span> In pool mining, rewards are split based on your contributed hashrate percentage.
                        </li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* FAQ Tab */}
              <TabsContent value="faq">
                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader className="border-b border-zinc-800">
                    <CardTitle className="text-lg text-gray-100">Frequently Asked Questions</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <Accordion type="single" collapsible className="space-y-2">
                      <AccordionItem value="faq-1" className="border-zinc-800 px-2">
                        <AccordionTrigger className="text-gray-200 hover:text-gray-100 py-3">
                          What is Sofestika and how does it work?
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-400 text-sm pt-2 pb-4">
                          Sofestika is a distributed Monero mining application that allows users to combine their computing resources to mine Monero cryptocurrency. Users contribute their hash power to a collective pool, increasing the chances of finding blocks and earning rewards. These rewards are then distributed among all participants proportionally to their hash power contribution.
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem value="faq-2" className="border-zinc-800 px-2">
                        <AccordionTrigger className="text-gray-200 hover:text-gray-100 py-3">
                          How are mining rewards calculated and distributed?
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-400 text-sm pt-2 pb-4">
                          Mining rewards are calculated based on your contributed hash power as a percentage of the total pool hash power. When the pool finds a block, the reward is distributed to all miners proportionally to their contribution. For example, if your hash power represents 1% of the pool's total, you'll receive approximately 1% of the rewards found by the pool. Payments are processed automatically once your balance reaches the payment threshold.
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem value="faq-3" className="border-zinc-800 px-2">
                        <AccordionTrigger className="text-gray-200 hover:text-gray-100 py-3">
                          What hardware is best for mining Monero?
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-400 text-sm pt-2 pb-4">
                          Monero's RandomX algorithm is CPU-optimized, making it ideal for processor mining rather than GPU mining. AMD Ryzen processors tend to perform best due to their cache size and architecture. The Ryzen 9 series (3900X, 5900X) and Ryzen 7 series (3700X, 5800X) are excellent choices. Intel Core i7 and i9 processors also perform well. For memory, at least 8GB of RAM is recommended, but 16GB offers better performance.
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem value="faq-4" className="border-zinc-800 px-2">
                        <AccordionTrigger className="text-gray-200 hover:text-gray-100 py-3">
                          Will mining affect my computer's performance?
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-400 text-sm pt-2 pb-4">
                          Yes, mining utilizes your CPU resources which can affect your computer's performance during other tasks. You can adjust how many CPU threads to dedicate to mining in the settings to find the right balance. The idle mining option can also be enabled to only mine when your computer is not in active use. Sofestika is designed to be configurable so you can find the right balance between mining efficiency and system usability.
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem value="faq-5" className="border-zinc-800 px-2">
                        <AccordionTrigger className="text-gray-200 hover:text-gray-100 py-3">
                          How do I withdraw my earned Monero?
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-400 text-sm pt-2 pb-4">
                          Payouts are automatically processed when your balance reaches the payment threshold (default is 0.01 XMR). The payment is sent directly to the Monero wallet address you specified in your account settings. You can also request a manual withdrawal from the Rewards page if you want to withdraw before reaching the threshold, although minimum withdrawal amounts may apply. Make sure your wallet address is correct as cryptocurrency transactions cannot be reversed.
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem value="faq-6" className="border-zinc-800 px-2">
                        <AccordionTrigger className="text-gray-200 hover:text-gray-100 py-3">
                          Is my computer suitable for mining?
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-400 text-sm pt-2 pb-4">
                          Most modern computers with multi-core processors can mine Monero. However, mining profitability depends on your CPU's hash rate, your electricity costs, and current Monero prices. Sofestika provides real-time estimates of your earnings to help you evaluate if mining is worthwhile for your specific setup. In general, computers with AMD Ryzen processors from the past few generations tend to be the most efficient for Monero mining.
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem value="faq-7" className="border-zinc-800 px-2">
                        <AccordionTrigger className="text-gray-200 hover:text-gray-100 py-3">
                          How can I increase my mining rewards?
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-400 text-sm pt-2 pb-4">
                          You can increase your mining rewards by: 1) Optimizing your hardware settings for better performance, 2) Using a computer with a more powerful CPU, 3) Mining consistently for longer periods, 4) Inviting friends to join the pool through your referral link to earn bonus rewards, and 5) Keeping your mining software updated for the latest optimizations. The Settings page provides options to adjust your mining configuration for optimal performance.
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Troubleshooting Tab */}
              <TabsContent value="troubleshooting">
                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader className="border-b border-zinc-800">
                    <CardTitle className="text-lg text-gray-100">Common Issues & Solutions</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <Accordion type="single" collapsible className="space-y-2">
                      <AccordionItem value="issue-1" className="border-zinc-800 px-2">
                        <AccordionTrigger className="text-gray-200 hover:text-gray-100 py-3">
                          Low Hashrate
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-400 text-sm pt-2 pb-4">
                          <p className="mb-2">If your hashrate is lower than expected, try these solutions:</p>
                          <ul className="list-disc list-inside space-y-1">
                            <li>Increase the number of mining threads in Settings</li>
                            <li>Close other CPU-intensive applications</li>
                            <li>Make sure your computer is not overheating</li>
                            <li>Update your CPU drivers</li>
                            <li>Check if your antivirus is interfering with the mining process</li>
                            <li>Try running the application as administrator</li>
                          </ul>
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem value="issue-2" className="border-zinc-800 px-2">
                        <AccordionTrigger className="text-gray-200 hover:text-gray-100 py-3">
                          Connection Issues
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-400 text-sm pt-2 pb-4">
                          <p className="mb-2">If you're having trouble connecting to the mining pool:</p>
                          <ul className="list-disc list-inside space-y-1">
                            <li>Check your internet connection</li>
                            <li>Verify that the pool address is correct in Settings</li>
                            <li>Temporarily disable your firewall or add an exception</li>
                            <li>Try using a different DNS server</li>
                            <li>Check if the mining pool is operational (status.hashshare.io)</li>
                            <li>Restart the application and your computer</li>
                          </ul>
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem value="issue-3" className="border-zinc-800 px-2">
                        <AccordionTrigger className="text-gray-200 hover:text-gray-100 py-3">
                          High Rejected Shares Rate
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-400 text-sm pt-2 pb-4">
                          <p className="mb-2">If you're experiencing a high rate of rejected shares:</p>
                          <ul className="list-disc list-inside space-y-1">
                            <li>Check for network instability or high latency</li>
                            <li>Try connecting to a geographically closer pool server</li>
                            <li>Reduce your CPU mining threads if your processor is overloaded</li>
                            <li>Update to the latest version of Sofestika</li>
                            <li>Lower your CPU priority in mining settings</li>
                            <li>Check for hardware instability or overheating</li>
                          </ul>
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem value="issue-4" className="border-zinc-800 px-2">
                        <AccordionTrigger className="text-gray-200 hover:text-gray-100 py-3">
                          Application Crashes or Freezes
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-400 text-sm pt-2 pb-4">
                          <p className="mb-2">If Sofestika crashes or freezes during operation:</p>
                          <ul className="list-disc list-inside space-y-1">
                            <li>Reduce the number of mining threads</li>
                            <li>Ensure your system meets the minimum requirements</li>
                            <li>Check for resource conflicts with other applications</li>
                            <li>Update your operating system and drivers</li>
                            <li>Try reinstalling the application</li>
                            <li>Check system logs for error messages</li>
                            <li>Submit a crash report from the Help menu</li>
                          </ul>
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem value="issue-5" className="border-zinc-800 px-2">
                        <AccordionTrigger className="text-gray-200 hover:text-gray-100 py-3">
                          Missing Payments
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-400 text-sm pt-2 pb-4">
                          <p className="mb-2">If you think you've missed a payment:</p>
                          <ul className="list-disc list-inside space-y-1">
                            <li>Verify that your balance reached the payment threshold</li>
                            <li>Check that your wallet address is entered correctly</li>
                            <li>Confirm the transaction on a Monero blockchain explorer</li>
                            <li>Be aware that payments may take up to 24 hours to process</li>
                            <li>Check the pool's announcement page for any payment system maintenance</li>
                            <li>Contact support if the issue persists</li>
                          </ul>
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem value="issue-6" className="border-zinc-800 px-2">
                        <AccordionTrigger className="text-gray-200 hover:text-gray-100 py-3">
                          High CPU Temperature
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-400 text-sm pt-2 pb-4">
                          <p className="mb-2">If your CPU is running too hot during mining:</p>
                          <ul className="list-disc list-inside space-y-1">
                            <li>Reduce the number of mining threads</li>
                            <li>Clean your computer's cooling system and fans</li>
                            <li>Ensure proper airflow around your computer</li>
                            <li>Use the power saving mode in Settings</li>
                            <li>Consider upgrading your CPU cooler</li>
                            <li>Use the idle mining feature to allow cooling breaks</li>
                          </ul>
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Contact Support Tab */}
              <TabsContent value="contact">
                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader className="border-b border-zinc-800">
                    <CardTitle className="text-lg text-gray-100">Contact Support</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <p className="text-gray-400 mb-6">
                      Can't find the answer you're looking for? Our support team is ready to help you with any questions or issues you might have.
                    </p>

                    <form className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="name" className="block text-sm text-gray-400 mb-1">
                            Name
                          </label>
                          <Input 
                            id="name" 
                            className="bg-zinc-800 border-zinc-700 text-gray-300"
                          />
                        </div>
                        <div>
                          <label htmlFor="email" className="block text-sm text-gray-400 mb-1">
                            Email
                          </label>
                          <Input 
                            id="email" 
                            type="email" 
                            className="bg-zinc-800 border-zinc-700 text-gray-300"
                          />
                        </div>
                      </div>
                      <div>
                        <label htmlFor="subject" className="block text-sm text-gray-400 mb-1">
                          Subject
                        </label>
                        <Input 
                          id="subject" 
                          className="bg-zinc-800 border-zinc-700 text-gray-300"
                        />
                      </div>
                      <div>
                        <label htmlFor="message" className="block text-sm text-gray-400 mb-1">
                          Message
                        </label>
                        <textarea 
                          id="message" 
                          rows={5} 
                          className="w-full rounded-md bg-zinc-800 border-zinc-700 text-gray-300 p-2 focus:ring-blue-500 focus:border-blue-500"
                        ></textarea>
                      </div>
                      <div>
                        <Button className="bg-blue-600 hover:bg-blue-700">
                          Submit Support Request
                        </Button>
                      </div>
                    </form>

                    <div className="mt-8 pt-6 border-t border-zinc-800">
                      <h3 className="text-md font-medium text-gray-200 mb-4">Other Ways to Get Help</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-zinc-800 p-4 rounded-lg text-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="h-6 w-6 text-blue-500 mx-auto mb-2"
                          >
                            <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                            <polyline points="14 2 14 8 20 8" />
                          </svg>
                          <h4 className="text-sm font-medium text-gray-200 mb-1">Documentation</h4>
                          <p className="text-xs text-gray-400">
                            Browse our detailed documentation for in-depth information
                          </p>
                        </div>
                        <div className="bg-zinc-800 p-4 rounded-lg text-center">
                          <svg viewBox="0 0 24 24" className="h-6 w-6 text-indigo-500 mx-auto mb-2" fill="currentColor">
                            <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
                          </svg>
                          <h4 className="text-sm font-medium text-gray-200 mb-1">Discord Community</h4>
                          <p className="text-xs text-gray-400">
                            Join our Discord server to chat with other miners and get community support
                          </p>
                        </div>
                        <div className="bg-zinc-800 p-4 rounded-lg text-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="h-6 w-6 text-green-500 mx-auto mb-2"
                          >
                            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                          </svg>
                          <h4 className="text-sm font-medium text-gray-200 mb-1">Live Chat</h4>
                          <p className="text-xs text-gray-400">
                            Contact our support team via live chat during business hours
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}
