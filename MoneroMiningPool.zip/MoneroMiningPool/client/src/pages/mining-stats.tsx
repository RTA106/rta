import { Sidebar } from "@/components/ui/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import { useMining } from "@/contexts/mining-context";
import { formatHashrate } from "@/lib/mining";

export default function MiningStats() {
  const { 
    userHashrate, 
    poolHashrate, 
    sharesAccepted, 
    sharesRejected, 
    dailyEarnings, 
    weeklyEarnings, 
    totalEarnings 
  } = useMining();

  // Sample data for charts
  const hashrateData = [
    { name: "00:00", value: 2.1 },
    { name: "02:00", value: 2.3 },
    { name: "04:00", value: 2.2 },
    { name: "06:00", value: 2.5 },
    { name: "08:00", value: 2.3 },
    { name: "10:00", value: 2.4 },
    { name: "12:00", value: 2.6 },
    { name: "14:00", value: 2.5 },
    { name: "16:00", value: 2.7 },
    { name: "18:00", value: 2.4 },
    { name: "20:00", value: 2.3 },
    { name: "22:00", value: 2.4 },
  ];

  const earningsData = [
    { name: "Mon", value: 0.00021 },
    { name: "Tue", value: 0.00019 },
    { name: "Wed", value: 0.00022 },
    { name: "Thu", value: 0.00020 },
    { name: "Fri", value: 0.00023 },
    { name: "Sat", value: 0.00021 },
    { name: "Sun", value: 0.00020 },
  ];

  // Pie chart data for hardware utilization
  const hardwareData = [
    { name: "CPU", value: 85 },
    { name: "Memory", value: 45 },
    { name: "Disk I/O", value: 20 },
    { name: "Network", value: 30 },
  ];

  const COLORS = ["#3B82F6", "#10B981", "#F59E0B", "#EF4444"];

  return (
    <div className="flex h-screen overflow-hidden bg-zinc-950 text-gray-100">
      <Sidebar />

      <div className="flex-1 md:pl-64 pt-16 md:pt-0">
        <main className="h-full overflow-y-auto pb-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 py-6">
            <div className="pb-5 border-b border-zinc-800 mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
              <h1 className="text-2xl font-semibold text-white">Sofestika Mining Statistics</h1>
              <div className="mt-4 md:mt-0">
                <Button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md">
                  Download Report
                </Button>
              </div>
            </div>

            {/* Stats Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card className="bg-zinc-900 border-zinc-800">
                <CardContent className="p-4">
                  <p className="text-gray-500 text-sm">Current Hashrate</p>
                  <h2 className="text-xl font-bold mt-1">{formatHashrate(userHashrate)}</h2>
                  <div className="flex items-center mt-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-green-500" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M12 7a1 1 0 01-1 1H9a1 1 0 01-1-1V6a1 1 0 011-1h2a1 1 0 011 1v1zm-1 4a1 1 0 00-1 1v1a1 1 0 001 1h2a1 1 0 001-1v-1a1 1 0 00-1-1h-2z" clipRule="evenodd" />
                      <path d="M5 5a2 2 0 00-2 2v8a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2H5zm10 2v8H5V7h10z" />
                    </svg>
                    <span className="text-xs text-gray-500 ml-1">CPU Mining</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-zinc-900 border-zinc-800">
                <CardContent className="p-4">
                  <p className="text-gray-500 text-sm">Shares (Accepted/Rejected)</p>
                  <h2 className="text-xl font-bold mt-1">{sharesAccepted.toLocaleString()} / {sharesRejected}</h2>
                  <Progress value={sharesAccepted > 0 ? (sharesAccepted / (sharesAccepted + sharesRejected)) * 100 : 100} className="h-2 mt-2 bg-zinc-800" />
                </CardContent>
              </Card>

              <Card className="bg-zinc-900 border-zinc-800">
                <CardContent className="p-4">
                  <p className="text-gray-500 text-sm">Total Earnings</p>
                  <h2 className="text-xl font-bold mt-1">{totalEarnings.toFixed(5)} XMR</h2>
                  <div className="flex items-center mt-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-amber-500" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" />
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z" clipRule="evenodd" />
                    </svg>
                    <span className="text-xs text-gray-500 ml-1">≈ ${(totalEarnings * 160.42).toFixed(2)} USD</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-zinc-900 border-zinc-800">
                <CardContent className="p-4">
                  <p className="text-gray-500 text-sm">Pool Contribution</p>
                  <h2 className="text-xl font-bold mt-1">
                    {userHashrate > 0 && poolHashrate > 0 
                      ? ((userHashrate / (poolHashrate * 1000)) * 100).toFixed(4) 
                      : "0.0000"}%
                  </h2>
                  <div className="flex items-center mt-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-500" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                    </svg>
                    <span className="text-xs text-gray-500 ml-1">Of {formatHashrate(poolHashrate * 1000)} total</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
              <Card className="bg-zinc-900 border-zinc-800 lg:col-span-2">
                <CardHeader className="p-5 border-b border-zinc-800">
                  <CardTitle className="text-lg font-medium">Hashrate History</CardTitle>
                </CardHeader>
                <CardContent className="p-5">
                  <Tabs defaultValue="day">
                    <TabsList className="bg-zinc-800 mb-4">
                      <TabsTrigger value="day" className="data-[state=active]:bg-zinc-700">Day</TabsTrigger>
                      <TabsTrigger value="week" className="data-[state=active]:bg-zinc-700">Week</TabsTrigger>
                      <TabsTrigger value="month" className="data-[state=active]:bg-zinc-700">Month</TabsTrigger>
                    </TabsList>
                    <TabsContent value="day" className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={hashrateData}>
                          <defs>
                            <linearGradient id="colorHashrate" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.8} />
                              <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#383838" vertical={false} />
                          <XAxis dataKey="name" tick={{ fill: '#9CA3AF' }} axisLine={{ stroke: '#383838' }} />
                          <YAxis tick={{ fill: '#9CA3AF' }} axisLine={{ stroke: '#383838' }} />
                          <Tooltip
                            contentStyle={{ backgroundColor: '#1E1E1E', borderColor: '#383838' }}
                            labelStyle={{ color: '#F3F4F6' }}
                            formatter={(value: any) => [`${value} KH/s`, 'Hashrate']}
                          />
                          <Area
                            type="monotone"
                            dataKey="value"
                            stroke="#3B82F6"
                            fillOpacity={1}
                            fill="url(#colorHashrate)"
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </TabsContent>
                    <TabsContent value="week" className="h-[300px]">
                      {/* Week chart would be similar */}
                      <div className="flex items-center justify-center h-full text-gray-500">Weekly data view</div>
                    </TabsContent>
                    <TabsContent value="month" className="h-[300px]">
                      {/* Month chart would be similar */}
                      <div className="flex items-center justify-center h-full text-gray-500">Monthly data view</div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>

              <Card className="bg-zinc-900 border-zinc-800">
                <CardHeader className="p-5 border-b border-zinc-800">
                  <CardTitle className="text-lg font-medium">Hardware Utilization</CardTitle>
                </CardHeader>
                <CardContent className="p-5">
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={hardwareData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                          {hardwareData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Legend />
                        <Tooltip
                          contentStyle={{ backgroundColor: '#1E1E1E', borderColor: '#383838' }}
                          labelStyle={{ color: '#F3F4F6' }}
                          formatter={(value: any) => [`${value}%`, 'Utilization']}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Earnings Charts */}
            <Card className="bg-zinc-900 border-zinc-800 mb-6">
              <CardHeader className="p-5 border-b border-zinc-800">
                <CardTitle className="text-lg font-medium">Earnings History</CardTitle>
              </CardHeader>
              <CardContent className="p-5">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={earningsData}>
                      <defs>
                        <linearGradient id="colorEarnings" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10B981" stopOpacity={0.8} />
                          <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#383838" vertical={false} />
                      <XAxis dataKey="name" tick={{ fill: '#9CA3AF' }} axisLine={{ stroke: '#383838' }} />
                      <YAxis 
                        tick={{ fill: '#9CA3AF' }} 
                        axisLine={{ stroke: '#383838' }} 
                        tickFormatter={(value) => value.toFixed(5)}
                      />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#1E1E1E', borderColor: '#383838' }}
                        labelStyle={{ color: '#F3F4F6' }}
                        formatter={(value: any) => [`${value.toFixed(5)} XMR`, 'Earnings']}
                      />
                      <Area
                        type="monotone"
                        dataKey="value"
                        stroke="#10B981"
                        fillOpacity={1}
                        fill="url(#colorEarnings)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Mining Efficiency Tips */}
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader className="p-5 border-b border-zinc-800">
                <CardTitle className="text-lg font-medium">Mining Efficiency Tips</CardTitle>
              </CardHeader>
              <CardContent className="p-5">
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="bg-blue-500/20 p-2 rounded-lg mr-3 mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-500" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-200">Optimize CPU Settings</h4>
                      <p className="text-sm text-gray-500 mt-1">
                        Adjust your CPU mining threads to match your processor's capabilities. Leaving 1-2 cores free can improve system responsiveness.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="bg-green-500/20 p-2 rounded-lg mr-3 mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-500" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-200">Keep Your System Cool</h4>
                      <p className="text-sm text-gray-500 mt-1">
                        Mining generates heat. Ensure proper ventilation and consider using temperature monitoring software to prevent thermal throttling.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="bg-amber-500/20 p-2 rounded-lg mr-3 mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-amber-500" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M11 3a1 1 0 10-2 0v1a1 1 0 102 0V3zM15.657 5.757a1 1 0 00-1.414-1.414l-.707.707a1 1 0 001.414 1.414l.707-.707zM18 10a1 1 0 01-1 1h-1a1 1 0 110-2h1a1 1 0 011 1zM5.05 6.464A1 1 0 106.464 5.05l-.707-.707a1 1 0 00-1.414 1.414l.707.707zM5 10a1 1 0 01-1 1H3a1 1 0 110-2h1a1 1 0 011 1zM8 16v-1h4v1a2 2 0 11-4 0zM12 14c.015-.34.208-.646.477-.859a4 4 0 10-4.954 0c.27.213.462.519.476.859h4.002z" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-200">Update Mining Software</h4>
                      <p className="text-sm text-gray-500 mt-1">
                        Regularly check for updates to the Sofestika mining software. New versions often include performance improvements and bug fixes.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
