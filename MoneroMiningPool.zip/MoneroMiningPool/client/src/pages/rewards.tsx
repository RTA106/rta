import { Sidebar } from "@/components/ui/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { useMining } from "@/contexts/mining-context";

export default function Rewards() {
  const { toast } = useToast();
  const { totalEarnings } = useMining();
  
  // Simulated XMR price in USD
  const xmrPrice = 160.42;

  // Fetch payouts data for the current user
  const { data: payoutsData = [] } = useQuery({
    queryKey: ["/api/payouts/1"], // Using hardcoded user ID 1 for demo
  });

  // Default values until data is loaded
  const currentBalance = 0.00794;
  const paymentThreshold = 0.01;
  const paymentProgress = (currentBalance / paymentThreshold) * 100;

  // Reward distribution data for the pie chart
  const distributionData = [
    { name: "Your Mining", value: 85 },
    { name: "Referral Bonus", value: 10 },
    { name: "Pool Bonus", value: 5 },
  ];

  const COLORS = ["#3B82F6", "#10B981", "#F59E0B"];

  const handleSaveSettings = () => {
    toast({
      title: "Payment Settings Saved",
      description: "Your reward payment settings have been updated",
      duration: 3000,
    });
  };

  const handleWithdraw = () => {
    toast({
      title: "Manual Withdrawal Requested",
      description: "Your withdrawal request has been submitted",
      duration: 3000,
    });
  };

  return (
    <div className="flex h-screen overflow-hidden bg-zinc-950 text-gray-100">
      <Sidebar />

      <div className="flex-1 md:pl-64 pt-16 md:pt-0">
        <main className="h-full overflow-y-auto pb-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 py-6">
            <div className="pb-5 border-b border-zinc-800 mb-6 flex flex-col md:flex-row md:items-center md:justify-between">
              <h1 className="text-2xl font-semibold text-white">Mining Rewards</h1>
              <div className="mt-4 md:mt-0 flex items-center space-x-3">
                <div className="flex items-center text-amber-500 px-3 py-1.5 rounded-full bg-zinc-800">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4 mr-1.5"
                  >
                    <circle cx="12" cy="12" r="10" />
                    <line x1="12" y1="8" x2="12" y2="16" />
                    <line x1="8" y1="12" x2="16" y2="12" />
                  </svg>
                  <span className="text-sm font-medium">XMR: ${xmrPrice.toFixed(2)}</span>
                </div>
                <Button
                  onClick={handleWithdraw}
                  className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md flex items-center"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4 mr-1.5"
                  >
                    <path d="M12 3v13" />
                    <path d="m5 10 7 7 7-7" />
                    <path d="M19 20H5" />
                  </svg>
                  <span>Manual Withdraw</span>
                </Button>
              </div>
            </div>

            {/* Rewards Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <Card className="bg-zinc-900 border-zinc-800">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-gray-500 text-sm mb-1">Current Balance</p>
                      <h2 className="text-2xl font-bold text-gray-100">
                        {currentBalance.toFixed(5)} <span className="text-sm font-normal">XMR</span>
                      </h2>
                      <p className="text-amber-500 text-xs mt-1">
                        ≈ ${(currentBalance * xmrPrice).toFixed(2)} USD
                      </p>
                    </div>
                    <div className="bg-zinc-800 p-2 rounded-lg">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-6 w-6 text-blue-500"
                      >
                        <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                        <circle cx="12" cy="12" r="3" />
                      </svg>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-500">Payment Threshold</span>
                      <span className="text-gray-300">{paymentThreshold.toFixed(2)} XMR</span>
                    </div>
                    <Progress value={paymentProgress} className="h-2 bg-zinc-700" />
                    <p className="text-xs text-gray-500 mt-1">
                      {paymentProgress.toFixed(1)}% of required amount for automatic payment
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-zinc-900 border-zinc-800">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-gray-500 text-sm mb-1">Total Earned</p>
                      <h2 className="text-2xl font-bold text-gray-100">
                        {totalEarnings.toFixed(5)} <span className="text-sm font-normal">XMR</span>
                      </h2>
                      <p className="text-amber-500 text-xs mt-1">
                        ≈ ${(totalEarnings * xmrPrice).toFixed(2)} USD
                      </p>
                    </div>
                    <div className="bg-zinc-800 p-2 rounded-lg">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-6 w-6 text-green-500"
                      >
                        <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
                      </svg>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">This Month</span>
                      <span className="text-gray-300">0.02347 XMR</span>
                    </div>
                    <div className="flex justify-between text-sm mt-1">
                      <span className="text-gray-500">Last Month</span>
                      <span className="text-gray-300">0.03912 XMR</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-zinc-900 border-zinc-800">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-gray-500 text-sm mb-1">Estimated Earnings</p>
                      <h2 className="text-2xl font-bold text-gray-100">
                        0.00219 <span className="text-sm font-normal">XMR/day</span>
                      </h2>
                      <p className="text-amber-500 text-xs mt-1">
                        ≈ ${(0.00219 * xmrPrice).toFixed(2)} USD/day
                      </p>
                    </div>
                    <div className="bg-zinc-800 p-2 rounded-lg">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-6 w-6 text-amber-500"
                      >
                        <rect width="20" height="14" x="2" y="5" rx="2" />
                        <line x1="2" x2="22" y1="10" y2="10" />
                      </svg>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Weekly</span>
                      <span className="text-gray-300">0.01533 XMR</span>
                    </div>
                    <div className="flex justify-between text-sm mt-1">
                      <span className="text-gray-500">Monthly</span>
                      <span className="text-gray-300">0.0657 XMR</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader className="border-b border-zinc-800">
                    <CardTitle className="text-lg text-gray-100">Payment History</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader className="bg-zinc-800">
                          <TableRow className="border-zinc-700">
                            <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Date</TableHead>
                            <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</TableHead>
                            <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Status</TableHead>
                            <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Transaction</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody className="bg-zinc-800 divide-y divide-zinc-700">
                          {payoutsData.length > 0 ? (
                            payoutsData.map((payout) => (
                              <TableRow key={payout.id}>
                                <TableCell className="whitespace-nowrap text-sm text-gray-200">
                                  {new Date(payout.timestamp).toLocaleString()}
                                </TableCell>
                                <TableCell className="whitespace-nowrap text-sm text-gray-200">
                                  {Number(payout.amount).toFixed(5)} XMR
                                </TableCell>
                                <TableCell className="whitespace-nowrap">
                                  <Badge 
                                    variant={payout.status === "completed" ? "success" : "secondary"}
                                    className={`${
                                      payout.status === "completed" 
                                        ? "bg-green-100 text-green-800" 
                                        : "bg-amber-100 text-amber-800"
                                    }`}
                                  >
                                    {payout.status.charAt(0).toUpperCase() + payout.status.slice(1)}
                                  </Badge>
                                </TableCell>
                                <TableCell className="whitespace-nowrap text-sm text-blue-500 hover:text-blue-400 cursor-pointer">
                                  {payout.transactionId ? 
                                    payout.transactionId.substring(0, 3) + '...' + 
                                    payout.transactionId.substring(payout.transactionId.length - 4) : 
                                    'Pending'}
                                </TableCell>
                              </TableRow>
                            ))
                          ) : (
                            <TableRow>
                              <TableCell colSpan={4} className="text-center py-4 text-gray-500">
                                No payment history available yet
                              </TableCell>
                            </TableRow>
                          )}
                        </TableBody>
                      </Table>
                    </div>

                    <div className="mt-6">
                      <h3 className="font-medium text-gray-100 mb-3">Payment Settings</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="wallet" className="block text-sm text-gray-400 mb-1">
                            Monero Wallet Address
                          </Label>
                          <Input 
                            id="wallet" 
                            value="4BrL51JCc9NGQ71kWhn...ANQs4pDSFQgLM" 
                            className="bg-zinc-800 border-zinc-700 text-gray-300"
                          />
                        </div>
                        <div>
                          <Label htmlFor="threshold" className="block text-sm text-gray-400 mb-1">
                            Payment Threshold (XMR)
                          </Label>
                          <Input 
                            id="threshold" 
                            type="number" 
                            defaultValue="0.01" 
                            min="0.001" 
                            step="0.001" 
                            className="bg-zinc-800 border-zinc-700 text-gray-300"
                          />
                        </div>
                        <div>
                          <Label htmlFor="method" className="block text-sm text-gray-400 mb-1">
                            Payment Method
                          </Label>
                          <select 
                            id="method" 
                            className="w-full rounded-md bg-zinc-800 border-zinc-700 text-gray-300 p-2 focus:ring-blue-500 focus:border-blue-500"
                          >
                            <option>Automatic (threshold-based)</option>
                            <option>Manual only</option>
                            <option>Weekly payout</option>
                          </select>
                        </div>
                        <div className="flex items-end">
                          <Button 
                            onClick={handleSaveSettings}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            Save Settings
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div>
                <Card className="bg-zinc-900 border-zinc-800 mb-6">
                  <CardHeader className="border-b border-zinc-800">
                    <CardTitle className="text-lg text-gray-100">Earnings Breakdown</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="h-[250px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={distributionData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          >
                            {distributionData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Legend />
                          <Tooltip
                            contentStyle={{ backgroundColor: '#1E1E1E', borderColor: '#383838' }}
                            labelStyle={{ color: '#F3F4F6' }}
                            formatter={(value) => [`${value}%`, null]}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="mt-4 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-400 flex items-center">
                          <span className="h-3 w-3 bg-blue-500 rounded-full inline-block mr-2"></span>
                          Your Mining
                        </span>
                        <span className="text-sm font-medium text-gray-200">0.10874 XMR</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-400 flex items-center">
                          <span className="h-3 w-3 bg-green-500 rounded-full inline-block mr-2"></span>
                          Referral Bonus
                        </span>
                        <span className="text-sm font-medium text-gray-200">0.01279 XMR</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-400 flex items-center">
                          <span className="h-3 w-3 bg-amber-500 rounded-full inline-block mr-2"></span>
                          Pool Bonus
                        </span>
                        <span className="text-sm font-medium text-gray-200">0.00641 XMR</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader className="border-b border-zinc-800">
                    <CardTitle className="text-lg text-gray-100">Reward Information</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium text-gray-200 text-sm">How Rewards Work</h3>
                        <p className="text-xs text-gray-400 mt-1">
                          Rewards are calculated based on your contributed hashrate as a percentage of the total pool hashrate.
                        </p>
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-200 text-sm">Payment Schedule</h3>
                        <p className="text-xs text-gray-400 mt-1">
                          Automatic payments are processed when your balance reaches the payment threshold (default: 0.01 XMR).
                        </p>
                      </div>
                      <div className="bg-zinc-800 p-3 rounded-lg">
                        <div className="flex items-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="h-5 w-5 text-blue-500 mr-2"
                          >
                            <circle cx="12" cy="12" r="10" />
                            <path d="M12 16v-4" />
                            <path d="M12 8h.01" />
                          </svg>
                          <h3 className="font-medium text-gray-200 text-sm">Increase Your Earnings</h3>
                        </div>
                        <p className="text-xs text-gray-400 mt-1">
                          Invite friends to mine with you and earn a 5% bonus on their mining rewards.
                        </p>
                        <Button className="w-full mt-2 bg-blue-600 hover:bg-blue-700 h-8 text-xs">
                          Get Referral Link
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
